<?php

	{	

		header('Content-Type: text/html; charset=iso-8859-1');

		set_time_limit(0);
		ini_set('memory_limit', '-1');      
		error_reporting(E_ALL);
		error_reporting(E_ALL ^ E_DEPRECATED); 
		ini_set('display_errors', TRUE); 
		ini_set('display_startup_errors', TRUE); 
		include("../init/function_cron.php");  
		include "get_function.php";
		include("../init/connexion.php");
		
	
?>

<!DOCTYPE html>
<html lang="fr">
<head>
	<link rel="stylesheet" href="coreui.min.css">
</head>
<body>
		 <?php		 
		 
		 if(empty($date_courant)){$date_courant="15022022";} else { $date_courant=date('dmY', mktime(date("H"), date('i'), date('s'),date('m'),date('d')-1,date('Y')));}
		
         ?>
        <div id="page-wrapper" style=" margin: 0px 0 0 5px;">		
            <div class="row">
                <div class="col-sm-12 col-lg-12">
					<?php 		
		

		                /*$directories = array("AUTORISATION_MOTIF_REJET", "DISPONIBILITE_HPSS_REJET", "ENROLEMENT_ECHOUE_ABANDON", 
						"EVOLUTION_CPT_INTEROPERABLE","GLOBAL_M_WALLETNTEROPERABLE","member_autorisation_tableLE","member_mcc_tableion_tableLE",
					    "member_pick_tableon_tableLE","STATE_M_WALLET_ACTIVEERABLE","TIME_RESPONSE_HPSSIVEERABLE");*/
						$directories = array_filter(glob('*'), '../recupe_piece_joint_mail/csv_files');

						foreach($directories as $directory){

							$nouveau_fichier = '../recupe_piece_joint_mail/csv_files/'.$directory.'/'.$directory.'_'.$date_courant.'.csv';
						    $libelle=$directory;
						    echo"<br> Heeere <br>";
						    importer_data_piece_joint_csv_vers_bdd($nouveau_fichier,$date_courant,$libelle);

						}

						
					
					
					?>
                </div>
           </div>
		</div>
</body>
</html>
<?php 
	}
?>
   