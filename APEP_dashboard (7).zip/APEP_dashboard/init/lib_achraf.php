<?php
include("connexion.php");


function get_service($service)
{
    $connexion = ma_db_connexion();
    $id_services = 0;
    $SQL= "SELECT id FROM service WHERE service like '".mysqli_real_escape_string($connexion,$service)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            $id_services = $row["id"];
        }
    }
    mysqli_close($connexion);
    return $id_services;

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_bank($bank)
{
    $connexion = ma_db_connexion();
    $id_bank = 0;
    $SQL= "SELECT id FROM membre WHERE name_membre like '".mysqli_real_escape_string($connexion,$bank)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            $id_bank = $row["id"];
        }
    }
    mysqli_close($connexion);
    return $id_bank;


}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_if_insert($date_data)
{
    $connexion = ma_db_connexion();
    $bool = false;
    $SQL= "SELECT id FROM etat_homologation_membres WHERE date_data = '".mysqli_real_escape_string($connexion,$date_data)."' limit 1";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            $bool = true;
        }
    }

    mysqli_close($connexion);
    return $bool;

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function insert_data($array,$date_data)
{

    foreach($array as $number_array)
    {
        foreach($number_array as $user_data)
        {
            $id_bank =get_id_bank($user_data[1]);
            $connexion = ma_db_connexion();
            $SQL= "INSERT INTO `etat_homologation_membres`(`id`, `date_data`, `id_service`, `id_bank_edp`, `value_etat`, `if_payeur`, `if_Integration`)
            VALUES (null,'".mysqli_real_escape_string($connexion,$date_data)."',
            '".mysqli_real_escape_string($connexion,$user_data[0])."',
            '".mysqli_real_escape_string($connexion,$id_bank)."',
            '".mysqli_real_escape_string($connexion,$user_data[2])."',
            '".mysqli_real_escape_string($connexion,$user_data[3])."',
            '".mysqli_real_escape_string($connexion,$user_data[4])."')";
            //echo "SQL : ".$SQL."<br><br>";

            mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
            $result=mysqli_query($connexion,$SQL);
            if (!$result)
            {
                error_log("Erreur SQL 9820324:  ".$SQL."  " .mysqli_error($connexion));
                die('ERREUR QUERY 9820324 !');
            }

            mysqli_close($connexion);
            /*  print "id_service : $user_data[0].  <br>";
              print "Bank : ".$id_bank. " <br>";
              print "Value Etat : $user_data[2].  <br>";
              print "IF Payeur : $user_data[3].  <br>";
              print "IF Integration : $user_data[4].  <br><br>";*/
        }
        //echo "**************************************************************<br><br>";
    }
}
/*************************************Files RAPPORT*************************************************************************/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function exporter_fichier_compteur($date_data,$name_fichier_xls)
{

    /************************************* Classeur 1 *************************************************************************/
    // Create new PHPExcel object
    $objPHPExcel = new PHPExcel();
    // Set active sheet index to the first sheet, so Excel opens this as the first sheet
    $objPHPExcel->setActiveSheetIndex(0);
    classeur_Fichier_stat_homologations($date_data,$objPHPExcel);
    $objPHPExcel->getActiveSheet()->setTitle('Etat des Homologations');
    /********************************************************************************************************************/
    /************************************* Classeur 2 *************************************************************************/
    $objPHPExcel->createSheet();
    // Set active sheet index to the first sheet, so Excel opens this as the first sheet
    $objPHPExcel->setActiveSheetIndex(1);
    classeur_Fichier_volume_intéroperable($date_data,$objPHPExcel);
    $objPHPExcel->getActiveSheet()->setTitle('Volume Intéropérable');
    /************************************* Classeurr 3 *************************************************************************/
    $objPHPExcel->createSheet();
    // Set active sheet index to the first sheet, so Excel opens this as the first sheet
    $objPHPExcel->setActiveSheetIndex(2);
    classeur_Fichier_Repartition_operations($date_data,$objPHPExcel);
    $objPHPExcel->getActiveSheet()->setTitle('Répartition des transactions');
    /************************************* Classeurr 4 *************************************************************************/
    $objPHPExcel->createSheet();
    // Set active sheet index to the first sheet, so Excel opens this as the first sheet
    $objPHPExcel->setActiveSheetIndex(3);
    classeur_Fichier_etat_enrolement($date_data,$objPHPExcel);
    $objPHPExcel->getActiveSheet()->setTitle('Etat des enrôlement');
    /************************************* Classeurr 5 *************************************************************************/
    $objPHPExcel->createSheet();
    // Set active sheet index to the first sheet, so Excel opens this as the first sheet
    $objPHPExcel->setActiveSheetIndex(4);
    classeur_Fichier_Statut_Transactions($date_data,$objPHPExcel);
    $objPHPExcel->getActiveSheet()->setTitle('Statut des transactions');
    /************************************* Classeurr 6 *************************************************************************/
    $objPHPExcel->createSheet();
    // Set active sheet index to the first sheet, so Excel opens this as the first sheet
    $objPHPExcel->setActiveSheetIndex(5);
    classeur_Fichier_Statut_Rejets($date_data,$objPHPExcel);
    $objPHPExcel->getActiveSheet()->setTitle('Volume des rejets par motif');
    /***************************************************END************************************************************************/
    // Save Excel 2007 file

    $rapportN2='rapport_excel/'.$name_fichier_xls.date("m-Y", strtotime($date_data)).'.xlsx';
    $callStartTime = microtime(true);
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
    $objWriter->save($rapportN2, __FILE__);
    $callEndTime = microtime(true);
    $callTime = $callEndTime - $callStartTime;
    $callStartTime = microtime(true);
    $objPHPExcel = PHPExcel_IOFactory::load($rapportN2, __FILE__);
    $callEndTime = microtime(true);
    $callTime = $callEndTime - $callStartTime;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_service_homologations()
{
    $service=array();
    $connexion=ma_db_connexion();
    // and id <> 16
    $SQL = "SELECT id,service FROM service WHERE etat = 1 ORDER BY `service`.`categorie` ASC";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {

                $service[]=[$row["id"],$row["service"]];
            }
        }
    }
    mysqli_close($connexion);
    return $service;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function classeur_Fichier_stat_homologations($date_data,$objPHPExcel)
{
    $date_data = '2022-03-01';
    $all_service = get_all_service_homologations();

    $objDrawing = new PHPExcel_Worksheet_Drawing();
    $objDrawing->setName('Logo');
    $objDrawing->setDescription('Logo');
    $objDrawing->setPath('img/logo_iprc2.png');
    $objDrawing->setCoordinates('K1');
    $objDrawing->setOffsetX(100);
    $objDrawing->setRotation(0);
    $objDrawing->getShadow()->setVisible(true);
    $objDrawing->getShadow()->setDirection(45);
    $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());


    // Set document properties

    $objPHPExcel->getProperties()->setCreator("HPS");

    ////////////////////////////Style////////////////////////////////////////////////////////////
    $sharedStyle = new PHPExcel_Style();
    $sharedStyle->applyFromArray(
        array('fill' 	=> array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => '002060'),
        )

        ));
    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );
    $styleService_Det = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 11,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'd9d9d9'),
        )
    );

    $styleService_Detail = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 9,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'd9d9d9'),
        )
    );

    $current_year=date("Y");

    $number=date('m', strtotime('-3 MONTH'))-1;
	$mois_abb=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Décembre'];
	$lastMonth=$mois_abb[$number];


    ////////////////////////////////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A6:E6");
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A36:B36");
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A45:E45");
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A75:B75");
    $objRichTitre = new PHPExcel_RichText();
    $NomTitre="Etat des Homologations à fin ".$lastMonth." ".$current_year." - Payeur";
    $NomTitre_2="Etat des Homologations à fin ".$lastMonth." ".$current_year." - Payé";
    $objTitre = $objRichTitre->createTextRun($NomTitre);
    $objTitre->getFont()->setBold(true);
    $objTitre->getFont()->setSize(15);
    //$objTitre->getFont()->setItalic(true);
    $objTitre->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );


    $objRichTitre_2 = new PHPExcel_RichText();
    $objTitre_2 = $objRichTitre_2->createTextRun($NomTitre_2);
    $objTitre_2->getFont()->setBold(true);
    $objTitre_2->getFont()->setSize(15);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_2->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A6')->setValue($objRichTitre);
    $objPHPExcel->getActiveSheet()->getStyle('A6')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A6:E6');

    $objPHPExcel->getActiveSheet()->getCell('A45')->setValue($objRichTitre_2);
    $objPHPExcel->getActiveSheet()->getStyle('A45')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A45:E45');

    $objPHPExcel->getActiveSheet()->mergeCells('A36:B36');
    $objPHPExcel->getActiveSheet()->mergeCells('B38:C38');
    $objPHPExcel->getActiveSheet()->mergeCells('B39:C39');
    $objPHPExcel->getActiveSheet()->mergeCells('B40:C40');
    $objPHPExcel->getActiveSheet()->mergeCells('B41:C41');
    $objPHPExcel->getActiveSheet()->mergeCells('B42:C42');
    $objPHPExcel->getActiveSheet()->mergeCells('A75:B75');
    $objPHPExcel->getActiveSheet()->mergeCells('B77:C77');
    $objPHPExcel->getActiveSheet()->mergeCells('B78:C78');
    $objPHPExcel->getActiveSheet()->mergeCells('B79:C79');
    $objPHPExcel->getActiveSheet()->mergeCells('B80:C80');
    $objPHPExcel->getActiveSheet()->mergeCells('B81:C81');
    $objPHPExcel->getActiveSheet()->mergeCells('A84:D84');




    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(4);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(17);
    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(21);

    $objPHPExcel->getActiveSheet()->getRowDimension('6')->setRowHeight(23);
    $objPHPExcel->getActiveSheet()->getRowDimension('7')->setRowHeight(23);
    $objPHPExcel->getActiveSheet()->getRowDimension('8')->setRowHeight(23);
    $objPHPExcel->getActiveSheet()->getRowDimension('9')->setRowHeight(24);
    $objPHPExcel->getActiveSheet()->getRowDimension('36')->setRowHeight(23);
    $objPHPExcel->getActiveSheet()->getRowDimension('45')->setRowHeight(23);
    $objPHPExcel->getActiveSheet()->getRowDimension('46')->setRowHeight(23);
    $objPHPExcel->getActiveSheet()->getRowDimension('47')->setRowHeight(23);
    $objPHPExcel->getActiveSheet()->getRowDimension('48')->setRowHeight(23);
    $objPHPExcel->getActiveSheet()->getRowDimension('75')->setRowHeight(23);

    /****************************Payeur***************************************/
    $objPHPExcel->getActiveSheet()->mergeCells('A8:B8');
    $objPHPExcel->getActiveSheet()->mergeCells('C8:E8');
    $objPHPExcel->getActiveSheet()->mergeCells('F8:H8');
    $objPHPExcel->getActiveSheet()->mergeCells('I8:J8');
    $objPHPExcel->getActiveSheet()->mergeCells('A9:B9');

    $objPHPExcel->getActiveSheet()->getCell('C8')->setValue('Services de base');
    $objPHPExcel->getActiveSheet()->getStyle('C8')->applyFromArray($styleService);

    $objPHPExcel->getActiveSheet()->getCell('F8')->setValue('Services Optionnels');
    $objPHPExcel->getActiveSheet()->getStyle('F8')->applyFromArray($styleService);

    $objPHPExcel->getActiveSheet()->getCell('I8')->setValue('Nouvelles Fonctionnalités');
    $objPHPExcel->getActiveSheet()->getStyle('I8')->applyFromArray($styleService);

    $objPHPExcel->getActiveSheet()->getCell('A9')->setValue('BQ/EDP');
    $objPHPExcel->getActiveSheet()->getStyle('A9')->applyFromArray($styleService_Det);


    $objPHPExcel->getActiveSheet()->getCell('C9')->setValue($all_service[0][1]);
    $objPHPExcel->getActiveSheet()->getStyle('C9')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('D9')->setValue($all_service[1][1]);
    $objPHPExcel->getActiveSheet()->getStyle('D9')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('E9')->setValue($all_service[2][1]);
    $objPHPExcel->getActiveSheet()->getStyle('E9')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('F9')->setValue($all_service[3][1]);
    $objPHPExcel->getActiveSheet()->getStyle('F9')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('G9')->setValue($all_service[4][1]);
    $objPHPExcel->getActiveSheet()->getStyle('G9')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('H9')->setValue($all_service[5][1]);
    $objPHPExcel->getActiveSheet()->getStyle('H9')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('I9')->setValue($all_service[6][1]);
    $objPHPExcel->getActiveSheet()->getStyle('I9')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('J9')->setValue($all_service[7][1]);
    $objPHPExcel->getActiveSheet()->getStyle('J9')->applyFromArray($styleService_Detail);

    $objPHPExcel->getActiveSheet()->getCell('A10')->setValue('BANQUES');
    $objPHPExcel->getActiveSheet()->getStyle('A10')->applyFromArray($styleService_Det);
    $objPHPExcel->getActiveSheet()->getStyle('A10')->getAlignment()->setTextRotation(90);

    $objPHPExcel->getActiveSheet()->getStyle('A18:B18')->applyFromArray(
        array('borders' => array(
            'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_MEDIUM,
                'color' => array('argb' => '808080'))
        )
        ));

    $objPHPExcel->getActiveSheet()->getCell('A19')->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getStyle('A19')->applyFromArray($styleService_Det);
    $objPHPExcel->getActiveSheet()->getStyle('A19')->getAlignment()->setTextRotation(90);


    $objPHPExcel->getActiveSheet()->getStyle('A33:B33')->applyFromArray(
        array('borders' => array(
            'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_MEDIUM,
                'color' => array('argb' => '808080'))
        )
        ));

    $objPHPExcel->getActiveSheet()->mergeCells('A10:A18');
    $objPHPExcel->getActiveSheet()->mergeCells('A19:A33');

    /****************************Payé***************************************/

    $objPHPExcel->getActiveSheet()->mergeCells('A47:B47');
    $objPHPExcel->getActiveSheet()->mergeCells('C47:E47');
    $objPHPExcel->getActiveSheet()->mergeCells('F47:H47');
    $objPHPExcel->getActiveSheet()->mergeCells('I47:J47');
    $objPHPExcel->getActiveSheet()->mergeCells('A48:B48');


    $objPHPExcel->getActiveSheet()->getCell('C47')->setValue('Services de base');
    $objPHPExcel->getActiveSheet()->getStyle('C47')->applyFromArray($styleService);

    $objPHPExcel->getActiveSheet()->getCell('F47')->setValue('Services Optionnels');
    $objPHPExcel->getActiveSheet()->getStyle('F47')->applyFromArray($styleService);

    $objPHPExcel->getActiveSheet()->getCell('I47')->setValue('Nouvelles Fonctionnalités');
    $objPHPExcel->getActiveSheet()->getStyle('I47')->applyFromArray($styleService);

    $objPHPExcel->getActiveSheet()->getCell('A48')->setValue('BQ/EDP');
    $objPHPExcel->getActiveSheet()->getStyle('A48')->applyFromArray($styleService_Det);

    $objPHPExcel->getActiveSheet()->getCell('C48')->setValue($all_service[0][1]);
    $objPHPExcel->getActiveSheet()->getStyle('C48')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('D48')->setValue($all_service[1][1]);
    $objPHPExcel->getActiveSheet()->getStyle('D48')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('E48')->setValue($all_service[2][1]);
    $objPHPExcel->getActiveSheet()->getStyle('E48')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('F48')->setValue($all_service[3][1]);
    $objPHPExcel->getActiveSheet()->getStyle('F48')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('G48')->setValue($all_service[4][1]);
    $objPHPExcel->getActiveSheet()->getStyle('G48')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('H48')->setValue($all_service[5][1]);
    $objPHPExcel->getActiveSheet()->getStyle('H48')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('I48')->setValue($all_service[6][1]);
    $objPHPExcel->getActiveSheet()->getStyle('I48')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('J48')->setValue($all_service[7][1]);
    $objPHPExcel->getActiveSheet()->getStyle('J48')->applyFromArray($styleService_Detail);



    $objPHPExcel->getActiveSheet()->getCell('A49')->setValue('BANQUES');
    $objPHPExcel->getActiveSheet()->getStyle('A49')->applyFromArray($styleService_Det);
    $objPHPExcel->getActiveSheet()->getStyle('A49')->getAlignment()->setTextRotation(90);

    $objPHPExcel->getActiveSheet()->getStyle('A57:B57')->applyFromArray(
        array('borders' => array(
            'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_MEDIUM,
                'color' => array('argb' => '808080'))
        )
        ));

    $objPHPExcel->getActiveSheet()->getCell('A58')->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getStyle('A58')->applyFromArray($styleService_Det);
    $objPHPExcel->getActiveSheet()->getStyle('A58')->getAlignment()->setTextRotation(90);


    $objPHPExcel->getActiveSheet()->getStyle('A72:B72')->applyFromArray(
        array('borders' => array(
            'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_MEDIUM,
                'color' => array('argb' => '808080'))
        )
        ));

    $objPHPExcel->getActiveSheet()->mergeCells('A49:A57');
    $objPHPExcel->getActiveSheet()->mergeCells('A58:A72');


    $objPHPExcel->getActiveSheet()->getCell('A84')->setValue('Nom complet BQ/EDP');
    $objPHPExcel->getActiveSheet()->getStyle('A84')->applyFromArray($styleService_Det);

    $objPHPExcel->getActiveSheet()->getCell('A85')->setValue('BANQUES');
    $objPHPExcel->getActiveSheet()->getStyle('A85')->applyFromArray($styleService_Det);
    $objPHPExcel->getActiveSheet()->getStyle('A85')->getAlignment()->setTextRotation(90);

    $objPHPExcel->getActiveSheet()->getStyle('A93:D93')->applyFromArray(
        array('borders' => array(
            'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_MEDIUM,
                'color' => array('argb' => '808080'))
        )
        ));

    $objPHPExcel->getActiveSheet()->getCell('A94')->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getStyle('A94')->applyFromArray($styleService_Det);
    $objPHPExcel->getActiveSheet()->getStyle('A94')->getAlignment()->setTextRotation(90);


    $objPHPExcel->getActiveSheet()->getStyle('A108:D108')->applyFromArray(
        array('borders' => array(
            'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_MEDIUM,
                'color' => array('argb' => '808080'))
        )
        ));

    $objPHPExcel->getActiveSheet()->getStyle('A83:D83')->applyFromArray(
        array('borders' => array(
            'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_MEDIUM,
                'color' => array('argb' => '808080'))
        )
        ));
    $objPHPExcel->getActiveSheet()->getStyle('D84:D108')->applyFromArray(
        array('borders' => array(
            'right'	=> array('style' => PHPExcel_Style_Border::BORDER_MEDIUM,
                'color' => array('argb' => '808080'))
        )
        ));

    $objPHPExcel->getActiveSheet()->mergeCells('A85:A93');
    $objPHPExcel->getActiveSheet()->mergeCells('A94:A108');

    /*******************************Rendre function *************************************/
    return_corps_msg($objPHPExcel,$all_service,$date_data,1, 10);
    return_corps_msg($objPHPExcel,$all_service,$date_data,0,49);
    /*******************************Fin Rendre function *********************************/

    return_detail_bank($objPHPExcel,85);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function classeur_Fichier_volume_intéroperable($date_data,$objPHPExcel)
{
    $objDrawing = new PHPExcel_Worksheet_Drawing();
    $objDrawing->setName('Logo');
    $objDrawing->setDescription('Logo');
    $objDrawing->setPath('img/logo_iprc2.png');
    $objDrawing->setCoordinates('O1');
    $objDrawing->setOffsetX(100);
    $objDrawing->setRotation(0);
    $objDrawing->getShadow()->setVisible(true);
    $objDrawing->getShadow()->setDirection(45);
    $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());


    // Set document properties

    $objPHPExcel->getProperties()->setCreator("HPS");
    ////////////////////////////Style////////////////////////////////////////////////////////////
    $sharedStyle = new PHPExcel_Style();
    $sharedStyle->applyFromArray(
        array('fill' 	=> array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => '002060'),
        )

        ));
    $styleService_Detail = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 9,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'd9d9d9'),
        )
    );
    $styleService_Det = new PHPExcel_Style();

    $styleService_Det->applyFromArray(array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'      => PHPExcel_Style_Fill::FILL_SOLID,
            'color'     => array('argb' => 'D0EBF6'),
        )
    ));
    ////////////////////////////Style////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A6:E6");
    $objRichTitre = new PHPExcel_RichText();
    $NomTitre="Total ouvertures annuel EDP/Banque";

    $objTitre = $objRichTitre->createTextRun($NomTitre);
    $objTitre->getFont()->setBold(true);
    $objTitre->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A6')->setValue($objRichTitre);
    $objPHPExcel->getActiveSheet()->getStyle('A6')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A6:E6');
    $objPHPExcel->getActiveSheet()->getRowDimension('6')->setRowHeight(23);

    ////////////////////////// TITLE 2 /////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A18:E18");
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Total ouvertures mensuel EDP/Banque";

    $objTitre_2 = $objRichTitre_2->createTextRun($NomTitre_2);
    $objTitre_2->getFont()->setBold(true);
    $objTitre_2->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_2->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A18')->setValue($objRichTitre_2);
    $objPHPExcel->getActiveSheet()->getStyle('A18')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A18:E18');
    $objPHPExcel->getActiveSheet()->getRowDimension('18')->setRowHeight(23);
    ////////////////////////////////////////////////////////////////////////////////////////////////

    
    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(21);

    $u = 10;
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(15);

    /*$B='EDP';
    $objPHPExcel->getActiveSheet()->getCell('B9')->setValue($B);
    $objPHPExcel->getActiveSheet()->getStyle('B9')->applyFromArray($styleService_Detail);

    $C='BANQUE';
    $objPHPExcel->getActiveSheet()->getCell('C9')->setValue($C);
    $objPHPExcel->getActiveSheet()->getStyle('C9')->applyFromArray($styleService_Detail);

    $D='SOMME';
    $objPHPExcel->getActiveSheet()->getCell('D9')->setValue($D);
    $objPHPExcel->getActiveSheet()->getStyle('D9')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getRowDimension(9)->setRowHeight(20);*/

    /*******************************Rendre function *************************************/
    //get_number_interoperable($objPHPExcel,$styleService_Detail,$u,$B,'B',0);
    //get_number_interoperable($objPHPExcel,$styleService_Detail,$u,$C,'C',0);
    //get_number_interoperable($objPHPExcel,$styleService_Detail,$u,$C,'D',1);

    get_indicateurs_annuel_interoperable($objPHPExcel,$u,$styleService_Det,$styleService_Detail);



    /*******************************Fin Rendre function *********************************/

    $u = 22;
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(15);

    /*$B='EDP';
    $objPHPExcel->getActiveSheet()->getCell('B9')->setValue($B);
    $objPHPExcel->getActiveSheet()->getStyle('B9')->applyFromArray($styleService_Detail);

    $C='BANQUE';
    $objPHPExcel->getActiveSheet()->getCell('C9')->setValue($C);
    $objPHPExcel->getActiveSheet()->getStyle('C9')->applyFromArray($styleService_Detail);

    $D='SOMME';
    $objPHPExcel->getActiveSheet()->getCell('D9')->setValue($D);
    $objPHPExcel->getActiveSheet()->getStyle('D9')->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getRowDimension(9)->setRowHeight(20);*/

    $u = 22;

    get_indicateurs_mensuel_interoperable($objPHPExcel,$u,$styleService_Det,$styleService_Detail);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_number_interoperable($objPHPExcel,$styleService_Detail,$u,$type,$column,$ifsum)
{
    $connexion = ma_db_connexion();

    $group = '`membre`.`type_membre` ,';
    $condi = "AND type_membre = '".$type."'";
    if ($ifsum===1)
    {
        $group = " ";
        $condi = " ";
    }
    // $date_data= date("Y-m-01",strtotime("-1 month"));

    $SQL = "SELECT type_membre,SUM(nb_services) AS `nb_services` ,DATE_FORMAT(`request_date` , '%Y') AS `year_data`
    FROM `evolution_cpt_interoperable` JOIN membre ON evolution_cpt_interoperable.bank_code=membre.code_membre WHERE  service_name='Enrôlement Client' AND returned_error_code=00000
    ".$condi."
    GROUP BY ".$group." DATE_FORMAT(`request_date` , '%Y') ORDER BY `year_data` ASC";

    //echo $SQL."<br>";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {

            $objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri')->setSize(9);
            while ($row = mysqli_fetch_assoc($result))
            {
                $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

                $objRichdate = new PHPExcel_RichText();
                $Date=$row['year_data'];
                $objdata = $objRichdate->createTextRun($Date);
                $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($objRichdate);
                $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_Detail);

                $objRichService = new PHPExcel_RichText();
                $nb_services = $row['nb_services'];
                $objService = $objRichService->createTextRun($nb_services);
                $objPHPExcel->getActiveSheet()->getCell($column.$u)->setValue($objRichService);
                if ($ifsum ===1)
                {
                    $objPHPExcel->getActiveSheet()->getStyle($column.$u)->applyFromArray($styleService_Detail);
                }

                
                $u++;
            }
        }
    }
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_number_mensuel_interoperable($type_bank,$month){

    $value_data = "0";
	$link = ma_db_connexion();
	$sql = "SELECT SUM(nb_services) as value_data FROM evolution_cpt_interoperable JOIN membre ON evolution_cpt_interoperable.bank_code=membre.code_membre  WHERE service_name='Enrôlement Client' AND returned_error_code=00000 AND DATE_FORMAT(`request_date` , '%Y-%m')='".$month."' AND type_membre='".$type_bank."' GROUP BY type_membre, DATE_FORMAT(`request_date` , '%Y-%m') ORDER BY request_date ASC";
	mysqli_query($link,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($link,$sql);
	 if (!$result)
		{
						error_log("Erreur sql service mensuel abouti : ".mysqli_error($link));
						die('ERREUR QUERY service mensuel abouti !');
		}
    if(mysqli_num_rows($result)>0)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            $value_data=$row["value_data"];
        }
    }
    mysqli_close($link);
    return $value_data;
}


function get_number_annuel_interoperable($type_bank,$year){

    $value_data = "0";
	$link = ma_db_connexion();
	$sql = "SELECT SUM(nb_services) as value_data FROM evolution_cpt_interoperable JOIN membre ON evolution_cpt_interoperable.bank_code=membre.code_membre  WHERE service_name='Enrôlement Client' AND returned_error_code=00000 AND DATE_FORMAT(`request_date` , '%Y')='".$year."' AND type_membre='".$type_bank."' GROUP BY type_membre, DATE_FORMAT(`request_date` , '%Y') ORDER BY request_date ASC";
	mysqli_query($link,"SET CHARACTER SET 'utf8'");
    //echo $sql;
    $result=mysqli_query($link,$sql);
	 if (!$result)
		{
						error_log("Erreur sql service mensuel abouti : ".mysqli_error($link));
						die('ERREUR QUERY service mensuel abouti !');
		}
    if(mysqli_num_rows($result)>0)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            $value_data=$row["value_data"];
        }
    }
    mysqli_close($link);
    return $value_data;
}

function get_indicateurs_annuel_interoperable($objPHPExcel,$u,$styleService_Det,$styleService_Detail)
{
    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);


    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService);
    //$objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':E'.$u);


    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('BANQUE');
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->applyFromArray($styleService);
   // $objPHPExcel->getActiveSheet()->mergeCells('H'.$u.':K'.$u);

   $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue('SOMME');
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService);
   // $objPHPExcel->getActiveSheet()->mergeCells('H'.$u.':K'.$u);

    $all_year = get_all_year_services();


    $u++;

    foreach($all_year as  $year)
    {
        $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);


        $objRichA = new PHPExcel_RichText();
        $A=$year;
        $objA = $objRichA->createTextRun($A);
        $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_Detail);



        //$service,$type_bank,$month
        //abouti
        $nbr_bank = get_number_annuel_interoperable('BANQUE',$year);
        $nbr_edp = get_number_annuel_interoperable('EDP',$year);
        $somme=$nbr_bank+$nbr_edp;
        



        //EDP
        $objRichB = new PHPExcel_RichText();
        $B=$nbr_bank;
        $objB = $objRichB->createTextRun($B);
        $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($objRichB);
        $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

        $objRichC = new PHPExcel_RichText();
        $C=$nbr_edp;
        $objC = $objRichC->createTextRun($C);
        $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($objRichC);
        $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

        $objRichD = new PHPExcel_RichText();
        $D=$somme;
        $objD = $objRichD->createTextRun($D);
        $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($objRichD);
        $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

        $u++;

   

    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_indicateurs_mensuel_interoperable($objPHPExcel,$u,$styleService_Det,$styleService_Detail)
{
    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);


    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService);
    //$objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':E'.$u);


    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('BANQUE');
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->applyFromArray($styleService);
   // $objPHPExcel->getActiveSheet()->mergeCells('H'.$u.':K'.$u);

   $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue('SOMME');
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService);
   // $objPHPExcel->getActiveSheet()->mergeCells('H'.$u.':K'.$u);

    $all_month = get_all_month_enrolement();


    $u++;

    foreach($all_month as  $month)
    {
        $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);


        $objRichA = new PHPExcel_RichText();
        $A=convert_month_to_french_excel($month[1]);
        $objA = $objRichA->createTextRun($A);
        $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_Detail);



        //$service,$type_bank,$month
        //abouti
        $nbr_bank = get_number_mensuel_interoperable('BANQUE',$month[0]);
        $nbr_edp = get_number_mensuel_interoperable('EDP',$month[0]);
        $somme=$nbr_bank+$nbr_edp;
        



        //EDP
        $objRichB = new PHPExcel_RichText();
        $B=$nbr_bank;
        $objB = $objRichB->createTextRun($B);
        $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($objRichB);
        $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

        $objRichC = new PHPExcel_RichText();
        $C=$nbr_edp;
        $objC = $objRichC->createTextRun($C);
        $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($objRichC);
        $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

        $objRichD = new PHPExcel_RichText();
        $D=$somme;
        $objD = $objRichD->createTextRun($D);
        $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($objRichD);
        $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

        $u++;

   

    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function return_corps_msg($objPHPExcel,$all_service,$date_data,$if_payeur,$u)
{
    $connexion = ma_db_connexion();

    // $date_data= date("Y-m-01",strtotime("-1 month"));

    $SQL = "SELECT id,name_membre FROM `membre` WHERE `etat` = 1 ORDER BY `membre`.`type_membre` ASC";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {

            $objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri')->setSize(9);
            while ($row = mysqli_fetch_assoc($result))
            {
                $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

                $objRichC = new PHPExcel_RichText();
                $C=$row["name_membre"];
                $objC = $objRichC->createTextRun($C);
                $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($objRichC);
                $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
                $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
                $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_JUSTIFY);

                return_value_homologation($row["id"],$all_service,$if_payeur,$date_data,$u,$objPHPExcel);

                $u++;
            }
        }
    }
    mysqli_close($connexion);
    $cell = 'A'.($u+2);
    $cell_1 = 'A'.($u+4); $cell_b_1 = 'B'.($u+4);$cell_b_c_1 = 'B'.($u+4).':C'.($u+4);
    $cell_2 = 'A'.($u+5); $cell_b_2 = 'B'.($u+5);$cell_b_c_2 = 'B'.($u+5).':C'.($u+5);
    $cell_3 = 'A'.($u+6); $cell_b_3 = 'B'.($u+6);$cell_b_c_3 = 'B'.($u+6).':C'.($u+6);
    $cell_4 = 'A'.($u+7); $cell_b_4 = 'B'.($u+7);$cell_b_c_4 = 'B'.($u+7).':C'.($u+7);
    $cell_5 = 'A'.($u+8); $cell_b_5 = 'B'.($u+8);$cell_b_c_5 = 'B'.($u+8).':C'.($u+8);

    $objRichTitre = new PHPExcel_RichText();
    $NomTitre="Légende";
    $objTitre = $objRichTitre->createTextRun($NomTitre);
    $objTitre->getFont()->setBold(true);
    $objTitre->getFont()->setSize(15);

    $objTitre->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );
    $objPHPExcel->getActiveSheet()->getCell($cell)->setValue($objRichTitre);
    $objPHPExcel->getActiveSheet()->getStyle($cell)->getAlignment()->setVertical('center');

    return_style_column(0,$cell_1,$objPHPExcel,1,true,false);
    $objPHPExcel->getActiveSheet()->getCell($cell_b_1)->setValue('Non intégré');
    $objPHPExcel->getActiveSheet()->getStyle($cell_b_c_1)->applyFromArray(array('borders' => array(
        'top'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'right'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'left'		=> array('style' => PHPExcel_Style_Border::BORDER_THIN)),'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
    )));

    return_style_column(50,$cell_2,$objPHPExcel,1,true,false);
    $objPHPExcel->getActiveSheet()->getCell($cell_b_2)->setValue('1% < Intégré < 50%');
    $objPHPExcel->getActiveSheet()->getStyle($cell_b_c_2)->applyFromArray(array('borders' => array(
        'top'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'right'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'left'		=> array('style' => PHPExcel_Style_Border::BORDER_THIN)),'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
    )));


    return_style_column(99,$cell_3,$objPHPExcel,1,true,false);
    $objPHPExcel->getActiveSheet()->getCell($cell_b_3)->setValue('51% < Homologué < 100%');
    $objPHPExcel->getActiveSheet()->getStyle($cell_b_c_3)->applyFromArray(array('borders' => array(
        'top'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'right'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'left'		=> array('style' => PHPExcel_Style_Border::BORDER_THIN)),'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
    )));


    return_style_column(100,$cell_4,$objPHPExcel,1,true,true);
    $objPHPExcel->getActiveSheet()->getCell($cell_b_4)->setValue('Actif');
    $objPHPExcel->getActiveSheet()->getStyle($cell_b_c_4)->applyFromArray(array('borders' => array(
        'top'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'right'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'left'		=> array('style' => PHPExcel_Style_Border::BORDER_THIN)),'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
    )));


   // echo $cell_5."<br>";

    return_style_column(0,$cell_5,$objPHPExcel,1,true,true);
    $objPHPExcel->getActiveSheet()->getCell($cell_b_5)->setValue('Non éligible');
    $objPHPExcel->getActiveSheet()->getStyle($cell_b_c_5)->applyFromArray(array('borders' => array(
        'top'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'right'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
        'left'		=> array('style' => PHPExcel_Style_Border::BORDER_THIN)),'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
    )));

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function return_detail_bank($objPHPExcel,$u)
{
    $connexion = ma_db_connexion();

    // $date_data= date("Y-m-01",strtotime("-1 month"));

    $SQL = "SELECT name_membre,nom_complet FROM `membre` WHERE `etat` = 1 ORDER BY `membre`.`type_membre` ASC";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {

            $objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri')->setSize(9);
            while ($row = mysqli_fetch_assoc($result))
            {
                $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

                $objRichC = new PHPExcel_RichText();
                $C=$row["name_membre"];
                $objC = $objRichC->createTextRun($C);
                $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($objRichC);
                $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
                $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
                $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_JUSTIFY);


                $objRichD = new PHPExcel_RichText();
                $objPHPExcel->getActiveSheet()->mergeCells('C'.$u.':D'.$u);
                $D=$row["nom_complet"];
                $objC = $objRichD->createTextRun($D);
                $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($objRichD);
                $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

                $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
                $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_JUSTIFY);

                $u++;
            }
        }
    }
    mysqli_close($connexion);

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function return_value_homologation($id_bank,$id_service,$if_payeur,$date_data,$u,$objPHPExcel)
{
    $connexion = ma_db_connexion();


    $type_bank = get_type_bank($id_bank);

    $codes = array('C','D','E','F','G','H','I','J');

    if ($type_bank)
    {
        unset($id_service[8]);
    }
    else
    {
        $id_service[7] = $id_service[8];
        unset($id_service[8]);
    }

    //echo "<pre>";echo print_r($id_service);echo "</pre>";die();
    foreach($id_service as $index => $number_array)
    {
        $value = get_value_bak_services($id_bank,$number_array[0],$if_payeur,$date_data);
        //echo $index."Value : ".$value."<br>";
        return_style_column($value,$codes[$index].$u,$objPHPExcel,$if_payeur,$type_bank,true);
    }
    //echo "<br>";

    mysqli_close($connexion);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_type_bank($id_bank)
{
    $bool = false;
    $connexion=ma_db_connexion();
    $SQL = "SELECT type_membre FROM membre WHERE id = '".mysqli_real_escape_string($connexion,$id_bank)."' ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            if ($row["type_membre"] === 'BANQUE')
            {
                $bool = true;
            }
        }
    }
    mysqli_close($connexion);
    return $bool;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function return_style_column($value,$index,$objPHPExcel,$if_payeur,$type_bank,$type)
{

    if (($if_payeur ===0 and $index[0]==='F' and !$type_bank and $value ==0) or $index ==='A42' or $index ==='A81')
    {
        $font_color='545454';
        $fill_color='bfbbbb';
        $value_final = "////////////////";
        //echo "index : ".$index ." type_bank : ".$type_bank ." if_payeur : ".$if_payeur."  value : ".$value."<br>";
    }
    else if ($value == 100)
    {
        $font_color='fafafa';
        $fill_color='005696';
        $value_final = '✓';
    }
    else if ($value > 50 and $value < 100)
    {
        $font_color='fafafa';
        $fill_color='537DC9';
        $value_final=$value . "%";
    }
    else if ($value > 1 and $value <= 50)
    {
        $font_color='fafafa';
        $fill_color='7F7F7F';
        $value_final=$value . "%";
    }

    else
    {
        $font_color='C00000';
        $fill_color='C00000';
        $value_final = " ";
    }

    $styleService_Det = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => $font_color),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => $fill_color),
        ), 'borders' => array(
            'top'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
            'right'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
            'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_THIN),
            'left'		=> array('style' => PHPExcel_Style_Border::BORDER_THIN))
    );

    if ($type)
    {
        $objPHPExcel->getActiveSheet()->getCell($index)->setValue($value_final);
    }

    $objPHPExcel->getActiveSheet()->getStyle($index)->applyFromArray($styleService_Det);
    //return $styleService_Det;

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_value_bak_services($id_bank,$id_service,$if_payeur,$date_data)
{
    $value = 0;
    $connexion=ma_db_connexion();
    $SQL = "SELECT `value` FROM etat_homologation_final WHERE id_bank_edp = ".$id_bank." AND id_service = '".$id_service."'
    AND if_payeur = ".$if_payeur." AND date_data = '".$date_data."'  ";
    //echo $SQL."<br>";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            $value=$row["value"];
        }
    }
    mysqli_close($connexion);
    return $value;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function classeur_Fichier_Repartition_operations($date_data,$objPHPExcel)
{

    $date_last_mois = date('Y-m-d', strtotime(' - 3 months'));


    $objDrawing = new PHPExcel_Worksheet_Drawing();
    $objDrawing->setName('Logo');
    $objDrawing->setDescription('Logo');
    $objDrawing->setPath('img/logo_iprc2.png');
    $objDrawing->setCoordinates('R1');
    $objDrawing->setOffsetX(100);
    $objDrawing->setRotation(0);
    $objDrawing->getShadow()->setVisible(true);
    $objDrawing->getShadow()->setDirection(45);
    $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());


    // Set document properties

    $objPHPExcel->getProperties()->setCreator("HPS");
    ////////////////////////////Style////////////////////////////////////////////////////////////
    $sharedStyle = new PHPExcel_Style();
    $sharedStyle->applyFromArray(
        array('fill' 	=> array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => '002060'),
        )

        ));
    $styleService_Detail = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 9,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'd9d9d9'),
        )
    );
    ////////////////////////////Title 1////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A6:G6");
    $objRichTitre = new PHPExcel_RichText();
    $NomTitre="Répartition des transactions en nombre (Trx) par service";

    $objTitre = $objRichTitre->createTextRun($NomTitre);
    $objTitre->getFont()->setBold(true);
    $objTitre->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A6')->setValue($objRichTitre);
    $objPHPExcel->getActiveSheet()->getStyle('A6')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A6:G6');
    $objPHPExcel->getActiveSheet()->getRowDimension('6')->setRowHeight(23);
    ////////////////////////////Title 2////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "K6:R6");
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Répartition des transactions en montant (Mad) par service";

    $objTitre_2 = $objRichTitre_2->createTextRun($NomTitre_2);
    $objTitre_2->getFont()->setBold(true);
    $objTitre_2->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_2->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('K6')->setValue($objRichTitre_2);
    $objPHPExcel->getActiveSheet()->getStyle('K6')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('K6:R6');
    $objPHPExcel->getActiveSheet()->getRowDimension('9')->setRowHeight(23);
    ////////////////////////////Title 3////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A19:G19");
    $objRichTitre_3 = new PHPExcel_RichText();
    $NomTitre_3="Répartition des transactions EDP/Banque en nombre (Trx)";

    $objTitre_3 = $objRichTitre_3->createTextRun($NomTitre_3);
    $objTitre_3->getFont()->setBold(true);
    $objTitre_3->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_3->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A19')->setValue($objRichTitre_3);
    $objPHPExcel->getActiveSheet()->getStyle('A19')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A19:G19');
    $objPHPExcel->getActiveSheet()->getRowDimension('19')->setRowHeight(23);
    $objPHPExcel->getActiveSheet()->getRowDimension('22')->setRowHeight(23);
    ////////////////////////////Title 4////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "K19:Q19");
    $objRichTitre_4 = new PHPExcel_RichText();
    $NomTitre_4="Répartition des transactions EDP/Banque en montant (Mad)";

    $objTitre_4 = $objRichTitre_4->createTextRun($NomTitre_4);
    $objTitre_4->getFont()->setBold(true);
    $objTitre_4->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_4->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('K19')->setValue($objRichTitre_4);
    $objPHPExcel->getActiveSheet()->getStyle('K19')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('K19:Q19');


    ////////////////////////////Title 5////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A32:G32");
    $objRichTitre_5 = new PHPExcel_RichText();

    $number=date('m', strtotime('-3 MONTH'))-1;
	$mois_abb=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Décembre'];
	$lastMonth=$mois_abb[$number];	
	$current_year=date("Y");
    $NomTitre_5="Répartition des transactions EDP/Banque en nombre (Trx) pour  ".$lastMonth." ".$current_year;

    $objTitre_5 = $objRichTitre_5->createTextRun($NomTitre_5);
    $objTitre_5->getFont()->setBold(true);
    $objTitre_5->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_5->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A32')->setValue($objRichTitre_5);
    $objPHPExcel->getActiveSheet()->getStyle('A32')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A32:G32');
    $objPHPExcel->getActiveSheet()->getRowDimension('32')->setRowHeight(23);
    $objPHPExcel->getActiveSheet()->getRowDimension('35')->setRowHeight(23);
    $objPHPExcel->getActiveSheet()->getRowDimension('36')->setRowHeight(23);
    ////////////////////////////Title 6////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "K32:Q32");
    $objRichTitre_6 = new PHPExcel_RichText();

    $number=date('m', strtotime('-3 MONTH'))-1;
	$mois_abb=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Décembre'];
	$lastMonth=$mois_abb[$number];	
	$current_year=date("Y");

    $NomTitre_6="Montant des transactions EDP/Banque en montant (Mad) pour ".$lastMonth." ".$current_year;

    $objTitre_6 = $objRichTitre_6->createTextRun($NomTitre_6);
    $objTitre_6->getFont()->setBold(true);
    $objTitre_6->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_6->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('K32')->setValue($objRichTitre_6);
    $objPHPExcel->getActiveSheet()->getStyle('K32')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('K32:Q32');

    ////////////////////////////fin title////////////////////////////////////////////////////////////

    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);

    $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(15);

    ////////////////////////////////////////////////////////////////////////////////////////////////////

    //echo $date_last_mois;




    ////////////////////////////////////////////////////////////////////////////////////////////////////

    /*******************************Rendre function *************************************/
    $u = 9;
    info_operation_service($objPHPExcel,$styleService_Detail,$u);
    $u = 22;
    info_operation_members($objPHPExcel,$styleService_Detail,$u);
    $u = 35;
    info_operation_last_month($objPHPExcel,$styleService_Detail,$date_last_mois,$u);

    /*******************************Fin Rendre function *********************************/
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function info_operation_service($objPHPExcel,$styleService_Detail,$u)
{
    $services = get_all_services();
    $all_year = get_all_year_services();
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($services[0]);
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($services[1]);
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($services[2]);
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($services[3]);
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_Detail);

    $objPHPExcel->getActiveSheet()->getCell('L'.$u)->setValue($services[0]);
    $objPHPExcel->getActiveSheet()->getStyle('L'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue($services[1]);
    $objPHPExcel->getActiveSheet()->getStyle('M'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('N'.$u)->setValue($services[2]);
    $objPHPExcel->getActiveSheet()->getStyle('N'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('O'.$u)->setValue($services[3]);
    $objPHPExcel->getActiveSheet()->getStyle('O'.$u)->applyFromArray($styleService_Detail);

    $u = $u+1;

    foreach($all_year as $year)
    {
        $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

        $objRichA = new PHPExcel_RichText();
        $A=$year;
        $objA = $objRichA->createTextRun($A);
        $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_Detail);

        $objPHPExcel->getActiveSheet()->getCell('K'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('K'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('K'.$u)->applyFromArray($styleService_Detail);


        $NBR_a = get_number_year_service('TRANSFERT',$year);
        $NBR_b = get_number_year_service('PAIEMENT',$year);
        $NBR_c = get_number_year_service('CASH OUT',$year);

        $NBR=$NBR_a+$NBR_b+$NBR_c;

        $MT_a = get_montant_year_service('TRANSFERT',$year);
        $MT_b = get_montant_year_service('PAIEMENT',$year);
        $MT_c = get_montant_year_service('CASH OUT',$year);

        $MT=$MT_a+$MT_b+$MT_c;


        
        $objRichC = new PHPExcel_RichText();
        $C=$NBR_a;
        $objC = $objRichC->createTextRun($C);
        $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($objRichC);
        $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

        $objRichD = new PHPExcel_RichText();
        $D=$NBR_b;
        $objD = $objRichD->createTextRun($D);
        $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($objRichD);
        $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

        $objRichB = new PHPExcel_RichText();
        $B=$NBR_c;
        $objB = $objRichB->createTextRun($B);
        $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($objRichB);
        $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

        $objRichE = new PHPExcel_RichText();
        $E=$NBR;
        $objE = $objRichE->createTextRun($E);
        $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($objRichE);
        $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

        $objRichM = new PHPExcel_RichText();
        $M=$MT_a;
        $objM = $objRichM->createTextRun($M);
        $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue($objRichM);
        $objPHPExcel->getActiveSheet()->getStyle('M'.$u)->getAlignment()->setWrapText(true);

        $objRichN = new PHPExcel_RichText();
        $N=$MT_b;
        $objN = $objRichN->createTextRun($N);
        $objPHPExcel->getActiveSheet()->getCell('N'.$u)->setValue($objRichN);
        $objPHPExcel->getActiveSheet()->getStyle('N'.$u)->getAlignment()->setWrapText(true);

        $objRichL = new PHPExcel_RichText();
        $L=$MT_c;
        $objL = $objRichL->createTextRun($L);
        $objPHPExcel->getActiveSheet()->getCell('L'.$u)->setValue($objRichL);
        $objPHPExcel->getActiveSheet()->getStyle('L'.$u)->getAlignment()->setWrapText(true);

        $objRichO = new PHPExcel_RichText();
        $O=$MT;
        $objO = $objRichO->createTextRun($O);
        $objPHPExcel->getActiveSheet()->getCell('O'.$u)->setValue($objRichO);
        $objPHPExcel->getActiveSheet()->getStyle('O'.$u)->getAlignment()->setWrapText(true);


    

        $u++;

    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function info_operation_members($objPHPExcel,$styleService_Detail,$u)
{
    $members = get_all_members();
    $all_year = get_all_year_services();
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($members[0]);
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($members[1]);
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($members[2]);
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService_Detail);


    $objPHPExcel->getActiveSheet()->getCell('L'.$u)->setValue($members[0]);
    $objPHPExcel->getActiveSheet()->getStyle('L'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue($members[1]);
    $objPHPExcel->getActiveSheet()->getStyle('M'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->getCell('N'.$u)->setValue($members[2]);
    $objPHPExcel->getActiveSheet()->getStyle('N'.$u)->applyFromArray($styleService_Detail);

    $u = $u+1;
    foreach($all_year as $year)
    {
        $codes = array('B','C');
        $codes_2 = array('L','M');
        //echo $year."<br>";
        $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

        $objRichA = new PHPExcel_RichText();
        $A=$year;
        $objC = $objRichA->createTextRun($A);
        $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_Detail);

        $objPHPExcel->getActiveSheet()->getCell('K'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('K'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('K'.$u)->applyFromArray($styleService_Detail);

        //foreach($members as $index => $member){

            //$value_a = get_value_year_members($member,$year,'SUM(nbr)');
            //$value_b = get_value_year_members($member,$year,'SUM(montant)');
            //echo $codes[$index].$u ."  ||  ".$year ."  ||  ". $member."  ||  ". $value_b . "<br>";

            //NB TRANSACTIONS:
        $value_a =get_number_annuel_operations_membre('BANQUE',$year);
        $value_b=get_number_annuel_operations_membre('EDP',$year);
        $somme=$value_a+$value_b;

        //EDP
        $objRichB = new PHPExcel_RichText();
        $B=$value_a;
        $objB = $objRichB->createTextRun($B);
        $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($objRichB);
        $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

        $objRichC = new PHPExcel_RichText();
        $C=$value_b;
        $objC = $objRichC->createTextRun($C);
        $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($objRichC);
        $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

        $objRichD = new PHPExcel_RichText();
        $D=$somme;
        $objD = $objRichD->createTextRun($D);
        $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($objRichD);
        $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

        //MONTANT TRANSACTIONS

        $value_a =get_montant_annuel_operations_membre('BANQUE',$year);
        $value_b=get_montant_annuel_operations_membre('EDP',$year);
        $somme=$value_a+$value_b;

        //EDP
        $objRichL = new PHPExcel_RichText();
        $L=$value_a;
        $objB = $objRichL->createTextRun($L);
        $objPHPExcel->getActiveSheet()->getCell('L'.$u)->setValue($objRichL);
        $objPHPExcel->getActiveSheet()->getStyle('L'.$u)->getAlignment()->setWrapText(true);

        $objRichM = new PHPExcel_RichText();
        $C=$value_b;
        $objC = $objRichM->createTextRun($C);
        $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue($objRichM);
        $objPHPExcel->getActiveSheet()->getStyle('M'.$u)->getAlignment()->setWrapText(true);

        $objRichN = new PHPExcel_RichText();
        $D=$somme;
        $objD = $objRichN->createTextRun($D);
        $objPHPExcel->getActiveSheet()->getCell('N'.$u)->setValue($objRichN);
        $objPHPExcel->getActiveSheet()->getStyle('N'.$u)->getAlignment()->setWrapText(true);


        //}

        $u++;

    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function info_operation_last_month($objPHPExcel,$styleService_Detail,$date_last_mois,$u)
{
    $array = get_paye_payeur_membre_previous_month($date_last_mois);
    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );
    $date_format = date('F - y', strtotime(' - 3 months'));

    /**add */
    $number=date('m', strtotime('-3 MONTH'))-1;
	$mois_abb=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Décembre'];
	$lastMonth=$mois_abb[$number];	
	$current_year=date("Y");
    

    $objPHPExcel->getActiveSheet()->mergeCells('A'.$u.':D'.$u);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($lastMonth.' '.$current_year);
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u.':D'.$u)->applyFromArray($styleService);

    $objPHPExcel->getActiveSheet()->mergeCells('K'.$u.':N'.$u);
    $objPHPExcel->getActiveSheet()->getCell('K'.$u)->setValue($lastMonth.' '.$current_year);
    $objPHPExcel->getActiveSheet()->getStyle('K'.$u.':N'.$u)->applyFromArray($styleService);

    $u = $u+1;

    $objPHPExcel->getActiveSheet()->mergeCells('A'.$u.':B'.$u);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue('PAYE');
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u.':B'.$u)->applyFromArray($styleService_Detail);

    $objPHPExcel->getActiveSheet()->mergeCells('C'.$u.':D'.$u);
    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('PAYEUR');
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u.':D'.$u)->applyFromArray($styleService_Detail);


    $objPHPExcel->getActiveSheet()->mergeCells('K'.$u.':L'.$u);
    $objPHPExcel->getActiveSheet()->getCell('K'.$u)->setValue('PAYE');
    $objPHPExcel->getActiveSheet()->getStyle('K'.$u.':L'.$u)->applyFromArray($styleService_Detail);

    $objPHPExcel->getActiveSheet()->mergeCells('M'.$u.':N'.$u);
    $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue('PAYEUR');
    $objPHPExcel->getActiveSheet()->getStyle('M'.$u.':N'.$u)->applyFromArray($styleService_Detail);

    $u = $u+1;
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(23);

    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($array[0][1]." ");
    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($array[1][1]." ");

    $objPHPExcel->getActiveSheet()->getCell('K'.$u)->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getCell('L'.$u)->setValue($array[2][1]." ");
    $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getCell('N'.$u)->setValue($array[3][1]." ");

    $u = $u+1;
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(23);

    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue('BANQUE');
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($array[0][0]." ");
    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('BANQUE');
    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($array[1][0]." ");

    $objPHPExcel->getActiveSheet()->getCell('K'.$u)->setValue('BANQUE');
    $objPHPExcel->getActiveSheet()->getCell('L'.$u)->setValue($array[2][0]." ");
    $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue('BANQUE');
    $objPHPExcel->getActiveSheet()->getCell('N'.$u)->setValue($array[3][0]." ");



}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_services()
{
    $services = array();
    $connexion=ma_db_connexion();
    $SQL = "SELECT `categorie` FROM operations WHERE processing_code != '00' ";
    //echo $SQL."<br>";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $services[]=$row["categorie"];
            }
            $services[] = 'SOMME';
        }
    }
    mysqli_close($connexion);
    return $services;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_members()
{
    $services = array();
    $connexion=ma_db_connexion();
    $SQL = "SELECT type_membre FROM `membre` where type_membre != 'null' GROUP by type_membre ";
    //echo $SQL."<br>";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $services[]=$row["type_membre"];
            }
            $services[] = 'SOMME';
        }
    }
    mysqli_close($connexion);
    return $services;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_year_services()
{
    $year_data = array();
    $connexion=ma_db_connexion();
    $SQL = "SELECT DATE_FORMAT(`date_author` , '%Y') AS `year_data` FROM `member_autorisation_tablele` 
    GROUP BY DATE_FORMAT(`date_author` , '%Y') ORDER BY `year_data` ASC ";
    //echo $SQL."<br>";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $year_data[]=$row["year_data"];
            }

        }
    }
    mysqli_close($connexion);
    return $year_data;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_value_year_services($service,$year,$column)
{
    $condition = "AND categorie = '".$service."'";
    $group_by = "GROUP BY categorie,DATE_FORMAT(`date_author` , '%Y')";
    if ($service == 'SOMME')
    {
        $condition = " ";
        $group_by = "GROUP BY DATE_FORMAT(`date_author` , '%Y')";
    }
    $value_data = "0";
    $connexion=ma_db_connexion();
    $SQL = "SELECT ".$column." AS value_data,DATE_FORMAT(`date_author` , '%Y') AS year FROM `member_autorisation_tablele` 
    JOIN operations ON member_autorisation_tablele.processing_code=operations.processing_code 
    WHERE ( action_code=000 OR (action_code=911 AND (member_autorisation_tablele.processing_code=23 or member_autorisation_tablele.processing_code=24))) 
    ".$condition."
    AND DATE_FORMAT(`date_author` , '%Y') = '".$year."' 
    ".$group_by." ORDER BY DATE_FORMAT(`date_author` , '%Y') ASC";
    //echo "<br><br>".$SQL."<br><br>";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $value_data=$row["value_data"];
            }
        }
    }
    mysqli_close($connexion);
    return $value_data;
}

function get_number_year_service($service,$year){

    $value_data = "0";
	$link = ma_db_connexion();
	$sql= "SELECT SUM(nbr) AS value_data FROM `member_autorisation_tablele` JOIN operations ON member_autorisation_tablele.processing_code=operations.processing_code WHERE DATE_FORMAT(`date_author` , '%Y')='".$year."' AND categorie='".$service."' AND ( action_code=000 OR (action_code=911 AND (member_autorisation_tablele.processing_code=23 or member_autorisation_tablele.processing_code=24))) GROUP BY categorie,DATE_FORMAT(`date_author` , '%Y') ORDER BY DATE_FORMAT(`date_author` , '%Y') ASC
    ";
    mysqli_query($link,"SET CHARACTER SET 'utf8'");
    //echo $sql;
    $result=mysqli_query($link,$sql);
	 if (!$result)
		{
						error_log("Erreur sql get_number_year_service : ".mysqli_error($link));
						die('ERREUR QUERY get_number_year_service !');
		}
    if(mysqli_num_rows($result)>0)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            $value_data=$row["value_data"];
        }
    }
    mysqli_close($link);
    return $value_data;
}

function get_montant_year_service($service,$year){

    $value_data = "0";
	$link = ma_db_connexion();
	$sql= "SELECT SUM(montant) AS value_data FROM `member_autorisation_tablele` JOIN operations ON member_autorisation_tablele.processing_code=operations.processing_code WHERE DATE_FORMAT(`date_author` , '%Y')='".$year."' AND categorie='".$service."' AND ( action_code=000 OR (action_code=911 AND (member_autorisation_tablele.processing_code=23 or member_autorisation_tablele.processing_code=24))) GROUP BY categorie,DATE_FORMAT(`date_author` , '%Y') ORDER BY DATE_FORMAT(`date_author` , '%Y') ASC
    ";
    mysqli_query($link,"SET CHARACTER SET 'utf8'");
    //echo $sql;
    $result=mysqli_query($link,$sql);
	 if (!$result)
		{
						error_log("Erreur sql get_number_year_service : ".mysqli_error($link));
						die('ERREUR QUERY get_number_year_service !');
		}
    if(mysqli_num_rows($result)>0)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            $value_data=$row["value_data"];
        }
    }
    mysqli_close($link);
    return $value_data;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_value_year_members($members,$year,$column)
{
    $condition = "AND type_membre = '".$members."'";
    $group_by = "GROUP BY membre.type_membre ,DATE_FORMAT(`date_author` , '%Y')";
    if ($members == 'SOMME')
    {
        $condition = " ";
        $group_by = "GROUP BY DATE_FORMAT(`date_author` , '%Y')";
    }
    $value_data = "0";
    $connexion=ma_db_connexion();
    $SQL = "SELECT ".$column." AS value_data FROM `member_autorisation_tablele`,`membre` 
    WHERE member_autorisation_tablele.issuing_bank = membre.code_membre AND
    ( action_code=000 OR (action_code=911 AND (member_autorisation_tablele.processing_code=23 or member_autorisation_tablele.processing_code=24))) ".$condition."
    AND DATE_FORMAT(`date_author` , '%Y') = '".$year."' 
    ".$group_by." ORDER BY DATE_FORMAT(`date_author` , '%Y') ASC";
    //echo "<br><br>".$SQL."<br><br>";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $value_data=$row["value_data"];
            }
        }
    }
    mysqli_close($connexion);
    return $value_data;
}

function get_number_annuel_operations_membre($type_bank,$year){

    $value_data = "0";
	$link = ma_db_connexion();
	$sql = "SELECT SUM(nbr) AS value_data FROM `member_autorisation_tablele`,`membre` WHERE member_autorisation_tablele.issuing_bank = membre.code_membre AND ( action_code=000 OR (action_code=911 AND (member_autorisation_tablele.processing_code=23 or member_autorisation_tablele.processing_code=24))) AND type_membre = '".$type_bank."' AND DATE_FORMAT(`date_author` , '%Y') = '".$year."' GROUP BY membre.type_membre ,DATE_FORMAT(`date_author` , '%Y') ORDER BY DATE_FORMAT(`date_author` , '%Y') ASC
    ";
	mysqli_query($link,"SET CHARACTER SET 'utf8'");
    //echo $sql;
    $result=mysqli_query($link,$sql);
	 if (!$result)
		{
						error_log("Erreur sql service mensuel abouti : ".mysqli_error($link));
						die('ERREUR QUERY service mensuel abouti !');
		}
    if(mysqli_num_rows($result)>0)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            $value_data=$row["value_data"];
        }
    }
    mysqli_close($link);
    return $value_data;
}

function get_montant_annuel_operations_membre($type_bank,$year){

    $value_data = "0";
	$link = ma_db_connexion();
	$sql = "SELECT SUM(montant) AS value_data FROM `member_autorisation_tablele`,`membre` WHERE member_autorisation_tablele.issuing_bank = membre.code_membre AND ( action_code=000 OR (action_code=911 AND (member_autorisation_tablele.processing_code=23 or member_autorisation_tablele.processing_code=24))) AND type_membre = '".$type_bank."' AND DATE_FORMAT(`date_author` , '%Y') = '".$year."' GROUP BY membre.type_membre ,DATE_FORMAT(`date_author` , '%Y') ORDER BY DATE_FORMAT(`date_author` , '%Y') ASC";
	mysqli_query($link,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($link,$sql);
	 if (!$result)
		{
						error_log("Erreur sql service mensuel abouti : ".mysqli_error($link));
						die('ERREUR QUERY service mensuel abouti !');
		}
    if(mysqli_num_rows($result)>0)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            $value_data=$row["value_data"];
        }
    }
    mysqli_close($link);
    return $value_data;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function classeur_Fichier_etat_enrolement($date_data,$objPHPExcel)
{

    $date_last_mois = date('Y-m-d', strtotime(' - 1 months'));

    $objDrawing = new PHPExcel_Worksheet_Drawing();
    $objDrawing->setName('Logo');
    $objDrawing->setDescription('Logo');
    $objDrawing->setPath('img/logo_iprc2.png');
    $objDrawing->setCoordinates('M1');
    $objDrawing->setOffsetX(100);
    $objDrawing->setRotation(0);
    $objDrawing->getShadow()->setVisible(true);
    $objDrawing->getShadow()->setDirection(45);
    $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());


    // Set document properties

    $objPHPExcel->getProperties()->setCreator("HPS");
    ////////////////////////////Style////////////////////////////////////////////////////////////
    $sharedStyle = new PHPExcel_Style();
    $sharedStyle->applyFromArray(
        array('fill' 	=> array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => '002060'),
        )

        ));
    $styleService_Detail = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 9,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'd9d9d9'),
        )
    );

    $styleService_gris_clair = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 9,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'e8e8e8'),
        )
    );
    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );
    $styleService_Det = new PHPExcel_Style();

    $styleService_Det->applyFromArray(array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'      => PHPExcel_Style_Fill::FILL_SOLID,
            'color'     => array('argb' => 'D0EBF6'),
        )
    ));
    ////////////////////////////Title 1////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A6:E6");
    $objRichTitre = new PHPExcel_RichText();
    $NomTitre="Statut annuel en nombre (Trx) et en montant (Mad)";

    $objTitre = $objRichTitre->createTextRun($NomTitre);
    $objTitre->getFont()->setBold(true);
    $objTitre->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A6')->setValue($objRichTitre);
    $objPHPExcel->getActiveSheet()->getStyle('A6')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A6:E6');
    $objPHPExcel->getActiveSheet()->getRowDimension('6')->setRowHeight(23);
    ////////////////////////////Title 2////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A42:E42");
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Statut annuel EDP/BANQUE en nombre (Trx) et en montant (Mad)";

    $objTitre_2 = $objRichTitre_2->createTextRun($NomTitre_2);
    $objTitre_2->getFont()->setBold(true);
    $objTitre_2->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_2->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A42')->setValue($objRichTitre_2);
    $objPHPExcel->getActiveSheet()->getStyle('A42')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A42:E42');
    $objPHPExcel->getActiveSheet()->getRowDimension('42')->setRowHeight(23);
    ////////////////////////////Title 4////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A57:E57");
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Statut mensuel EDP/BANQUE en nombre (Trx) et en montant (Mad)";

    $objTitre_2 = $objRichTitre_2->createTextRun($NomTitre_2);
    $objTitre_2->getFont()->setBold(true);
    $objTitre_2->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_2->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A57')->setValue($objRichTitre_2);
    $objPHPExcel->getActiveSheet()->getStyle('A57')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A57:E57');
    $objPHPExcel->getActiveSheet()->getRowDimension('57')->setRowHeight(23);
    ////////////////////////////Title 3////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A20:E20");
    $objRichTitre = new PHPExcel_RichText();
    $NomTitre="Statut mensuel en nombre (Trx) et en montant (Mad)";

    $objTitre = $objRichTitre->createTextRun($NomTitre);
    $objTitre->getFont()->setBold(true);
    $objTitre->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A20')->setValue($objRichTitre);
    $objPHPExcel->getActiveSheet()->getStyle('A20')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A20:E20');
    $objPHPExcel->getActiveSheet()->getRowDimension('20')->setRowHeight(23);
    
    
    ////////////////////////////fin title////////////////////////////////////////////////////////////

    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(21);


    ////////////////////////////////////////////////////////////////////////////////////////////////////

    /*******************************Rendre function *************************************/
    $u = 8;
    get_indicateurs_annuels_vol_mont($objPHPExcel,$u,$styleService_Det,$styleService_Detail,$styleService_gris_clair);

    $u = 20;
    get_indicateurs_mensuels_vol_mont($objPHPExcel,$u,$styleService_Det,$styleService_Detail,$styleService_gris_clair);

    $u = 44;
    get_indicateurs_annuels_bank_vol_mont($objPHPExcel,$u,$styleService_Det,$styleService_Detail,$styleService_gris_clair);

    $u = 57;
    get_indicateurs_mensuels_bank_vol_mont($objPHPExcel,$u,$styleService_Det,$styleService_Detail,$styleService_gris_clair);
    /*******************************Fin Rendre function *********************************/
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_indicateurs_mensuels_bank_vol_mont($objPHPExcel,$u,$styleService_Det,$styleService_Detail,$styleService_gris_clair)
{
    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    /*$objPHPExcel->getActiveSheet()->setSharedStyle($styleService_Det, 'A'.$u.':B'.$u);
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Indicateurs Mensuels";
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($NomTitre_2);
    $objPHPExcel->getActiveSheet()->mergeCells('A'.$u.':B'.$u);*/


    $u = $u+3;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':G'.$u);


    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('J'.$u)->setValue('BANQUE');
    $objPHPExcel->getActiveSheet()->getStyle('J'.$u)->applyFromArray($styleService);
    $objPHPExcel->getActiveSheet()->mergeCells('J'.$u.':O'.$u);

    $u++;
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Volume (Trx)');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':D'.$u);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue('Montant (Mad)');
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('E'.$u.':G'.$u);


    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('J'.$u)->setValue('Volume (Trx)');
    $objPHPExcel->getActiveSheet()->getStyle('J'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('J'.$u.':L'.$u);

    $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue('Montant (Mad)');
    $objPHPExcel->getActiveSheet()->getStyle('M'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('M'.$u.':O'.$u);
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue('Abandoné');
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('F'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('F'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('G'.$u)->setValue('Abandoné');
    $objPHPExcel->getActiveSheet()->getStyle('G'.$u)->applyFromArray($styleService_gris_clair);

    ///

    $objPHPExcel->getActiveSheet()->getCell('J'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('J'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('K'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('K'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('L'.$u)->setValue('Abandoné');
    $objPHPExcel->getActiveSheet()->getStyle('L'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('M'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('N'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('N'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('O'.$u)->setValue('Abandoné');
    $objPHPExcel->getActiveSheet()->getStyle('O'.$u)->applyFromArray($styleService_gris_clair);

    $all_month = get_all_month_enrolement();


    $u++;

    foreach($all_month as  $month)
    {
        $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);


        $objRichA = new PHPExcel_RichText();
        $A=convert_month_to_french_excel($month[1]);
        $objA = $objRichA->createTextRun($A);
        $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_gris_clair);

        $objPHPExcel->getActiveSheet()->getCell('I'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('I'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('I'.$u)->applyFromArray($styleService_gris_clair);


        $volume_data_succes_bank = get_enrolement_mensuel($month[0],0,'%Y-%m','BANQUE');
        $volume_data_succes_edp = get_enrolement_mensuel($month[0],0,'%Y-%m','EDP');

        $volume_data_echoue_bank = get_enrolement_mensuel($month[0],2,'%Y-%m','BANQUE');
        $volume_data_echoue_edp = get_enrolement_mensuel($month[0],2,'%Y-%m','EDP');

        $volume_data_aband_bank = get_enrolement_mensuel($month[0],1,'%Y-%m','BANQUE');
        $volume_data_aband_edp = get_enrolement_mensuel($month[0],1,'%Y-%m','EDP');

        $montant_data_succes = get_value_montant_enrolement($month[0],0);

        //edp

        $objRichB = new PHPExcel_RichText();
        $B=$volume_data_succes_edp;
        $objB = $objRichB->createTextRun($B);
        $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($objRichB);
        $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

        $objRichC = new PHPExcel_RichText();
        $C=$volume_data_echoue_edp;
        $objC = $objRichC->createTextRun($C);
        $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($objRichC);
        $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

        $objRichD = new PHPExcel_RichText();
        $D=$volume_data_aband_edp;
        $objd = $objRichD->createTextRun($D);
        $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($objRichD);
        $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

        $objRichE = new PHPExcel_RichText();
        $E=$montant_data_succes;
        $objD = $objRichE->createTextRun($E);
        $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($objRichE);
        $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

        $objRichF = new PHPExcel_RichText();
        $F=$montant_data_succes;
        $objE = $objRichF->createTextRun($F);
        $objPHPExcel->getActiveSheet()->getCell('F'.$u)->setValue($objRichF);
        $objPHPExcel->getActiveSheet()->getStyle('F'.$u)->getAlignment()->setWrapText(true);

        $objRichG = new PHPExcel_RichText();
        $G=$montant_data_succes;
        $objG = $objRichG->createTextRun($G);
        $objPHPExcel->getActiveSheet()->getCell('G'.$u)->setValue($objRichG);
        $objPHPExcel->getActiveSheet()->getStyle('G'.$u)->getAlignment()->setWrapText(true);


        //bank:
        $objRichJ = new PHPExcel_RichText();
        $J=$volume_data_succes_bank;
        $objJ = $objRichJ->createTextRun($J);
        $objPHPExcel->getActiveSheet()->getCell('J'.$u)->setValue($objRichJ);
        $objPHPExcel->getActiveSheet()->getStyle('J'.$u)->getAlignment()->setWrapText(true);

        $objRichK = new PHPExcel_RichText();
        $K=$volume_data_echoue_bank;
        $objK = $objRichK->createTextRun($K);
        $objPHPExcel->getActiveSheet()->getCell('K'.$u)->setValue($objRichK);
        $objPHPExcel->getActiveSheet()->getStyle('K'.$u)->getAlignment()->setWrapText(true);

        $objRichL = new PHPExcel_RichText();
        $L=$volume_data_aband_bank;
        $objL = $objRichL->createTextRun($L);
        $objPHPExcel->getActiveSheet()->getCell('L'.$u)->setValue($objRichL);
        $objPHPExcel->getActiveSheet()->getStyle('L'.$u)->getAlignment()->setWrapText(true);

        $objRichM = new PHPExcel_RichText();
        $M=$montant_data_succes;
        $objM = $objRichM->createTextRun($M);
        $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue($objRichM);
        $objPHPExcel->getActiveSheet()->getStyle('M'.$u)->getAlignment()->setWrapText(true);

        $objRichN = new PHPExcel_RichText();
        $N=$montant_data_succes;
        $objN = $objRichN->createTextRun($N);
        $objPHPExcel->getActiveSheet()->getCell('N'.$u)->setValue($objRichN);
        $objPHPExcel->getActiveSheet()->getStyle('N'.$u)->getAlignment()->setWrapText(true);

        $objRichO = new PHPExcel_RichText();
        $O=$montant_data_succes;
        $objO = $objRichO->createTextRun($O);
        $objPHPExcel->getActiveSheet()->getCell('O'.$u)->setValue($objRichO);
        $objPHPExcel->getActiveSheet()->getStyle('O'.$u)->getAlignment()->setWrapText(true);


        //echo "MONTH: ".$year. " || VALUE DATA Succes BANK: ".$volume_data_succes_bank."  ||  VALUE DATA Echoue BANK : ".$volume_data_echoue_bank."<br>";
        //echo "MONTH: ".$year. " || VALUE DATA Succes EDP: ".$volume_data_succes_edp."  ||  VALUE DATA Echoue EDP : ".$volume_data_echoue_edp."<br>";
        $u++;

    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_indicateurs_annuels_bank_vol_mont($objPHPExcel,$u,$styleService_Det,$styleService_Detail,$styleService_gris_clair)
{
    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    /*$objPHPExcel->getActiveSheet()->setSharedStyle($styleService_Det, 'A'.$u.':B'.$u);
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Indicateurs Annuels";
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($NomTitre_2);
    $objPHPExcel->getActiveSheet()->mergeCells('A'.$u.':B'.$u);*/


    $u = $u+1;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':G'.$u);


    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('J'.$u)->setValue('BANQUE');
    $objPHPExcel->getActiveSheet()->getStyle('J'.$u)->applyFromArray($styleService);
    $objPHPExcel->getActiveSheet()->mergeCells('J'.$u.':O'.$u);

    $u++;
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Volume (Trx)');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':D'.$u);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue('Montant (Mad)');
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('E'.$u.':G'.$u);


    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('J'.$u)->setValue('Volume (Trx)');
    $objPHPExcel->getActiveSheet()->getStyle('J'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('J'.$u.':L'.$u);

    $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue('Montant (Mad)');
    $objPHPExcel->getActiveSheet()->getStyle('M'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('M'.$u.':O'.$u);
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue('Abandoné');
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('F'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('F'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('G'.$u)->setValue('Abandoné');
    $objPHPExcel->getActiveSheet()->getStyle('G'.$u)->applyFromArray($styleService_gris_clair);
    
    //
    $objPHPExcel->getActiveSheet()->getCell('J'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('J'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('K'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('K'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('L'.$u)->setValue('Abandoné');
    $objPHPExcel->getActiveSheet()->getStyle('L'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('M'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('N'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('N'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('O'.$u)->setValue('Abandoné');
    $objPHPExcel->getActiveSheet()->getStyle('O'.$u)->applyFromArray($styleService_gris_clair);

    $all_year = get_all_year_enrolement();


    $u++;

    foreach($all_year as  $year)
    {
        $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);


        $objRichA = new PHPExcel_RichText();
        $A=$year;
        $objA = $objRichA->createTextRun($A);
        $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_gris_clair);

        $objPHPExcel->getActiveSheet()->getCell('I'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('I'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('I'.$u)->applyFromArray($styleService_gris_clair);

        $volume_data_succes_bank = get_value_vulume_enrolement_bank($year,0,'%Y','BANQUE');
        $volume_data_echoue_bank = get_value_vulume_enrolement_bank($year,2,'%Y','BANQUE');
        $volume_data_aband_bank = get_value_vulume_enrolement_bank($year,1,'%Y','BANQUE');



        $volume_data_succes_edp = get_value_vulume_enrolement_bank($year,0,'%Y','EDP');
        $volume_data_echoue_edp = get_value_vulume_enrolement_bank($year,2,'%Y','EDP');
        $volume_data_aband_edp = get_value_vulume_enrolement_bank($year,1,'%Y','EDP');


        $montant_data_succes = get_value_montant_enrolement($year,0);



        //EDP
        $objRichB = new PHPExcel_RichText();
        $B=$volume_data_succes_edp;
        $objB = $objRichB->createTextRun($B);
        $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($objRichB);
        $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

        $objRichC = new PHPExcel_RichText();
        $C=$volume_data_echoue_edp;
        $objC = $objRichC->createTextRun($C);
        $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($objRichC);
        $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

        $objRichD = new PHPExcel_RichText();
        $D=$volume_data_aband_edp;
        $objD = $objRichD->createTextRun($D);
        $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($objRichD);
        $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

        $objRichE = new PHPExcel_RichText();
        $E=$montant_data_succes;
        $objE = $objRichE->createTextRun($E);
        $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($objRichE);
        $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

        $objRichF = new PHPExcel_RichText();
        $F=$montant_data_succes;
        $objF = $objRichF->createTextRun($F);
        $objPHPExcel->getActiveSheet()->getCell('F'.$u)->setValue($objRichF);
        $objPHPExcel->getActiveSheet()->getStyle('F'.$u)->getAlignment()->setWrapText(true);

        $objRichG = new PHPExcel_RichText();
        $G=$montant_data_succes;
        $objG = $objRichG->createTextRun($G);
        $objPHPExcel->getActiveSheet()->getCell('G'.$u)->setValue($objRichG);
        $objPHPExcel->getActiveSheet()->getStyle('G'.$u)->getAlignment()->setWrapText(true);



        //bank

        $objRichJ = new PHPExcel_RichText();
        $J=$volume_data_succes_bank;
        $objJ = $objRichJ->createTextRun($J);
        $objPHPExcel->getActiveSheet()->getCell('J'.$u)->setValue($objRichJ);
        $objPHPExcel->getActiveSheet()->getStyle('J'.$u)->getAlignment()->setWrapText(true);

        $objRichK = new PHPExcel_RichText();
        $K=$volume_data_echoue_bank;
        $objK = $objRichK->createTextRun($K);
        $objPHPExcel->getActiveSheet()->getCell('K'.$u)->setValue($objRichK);
        $objPHPExcel->getActiveSheet()->getStyle('K'.$u)->getAlignment()->setWrapText(true);

        $objRichL = new PHPExcel_RichText();
        $L=$volume_data_aband_bank;
        $objL = $objRichL->createTextRun($L);
        $objPHPExcel->getActiveSheet()->getCell('L'.$u)->setValue($objRichL);
        $objPHPExcel->getActiveSheet()->getStyle('L'.$u)->getAlignment()->setWrapText(true);

        $objRichM = new PHPExcel_RichText();
        $M=$montant_data_succes;
        $objM = $objRichM->createTextRun($M);
        $objPHPExcel->getActiveSheet()->getCell('M'.$u)->setValue($objRichM);
        $objPHPExcel->getActiveSheet()->getStyle('M'.$u)->getAlignment()->setWrapText(true);

        $objRichN = new PHPExcel_RichText();
        $N=$montant_data_succes;
        $objN = $objRichN->createTextRun($N);
        $objPHPExcel->getActiveSheet()->getCell('N'.$u)->setValue($objRichN);
        $objPHPExcel->getActiveSheet()->getStyle('N'.$u)->getAlignment()->setWrapText(true);

        $objRichO = new PHPExcel_RichText();
        $O=$montant_data_succes;
        $objO = $objRichO->createTextRun($O);
        $objPHPExcel->getActiveSheet()->getCell('O'.$u)->setValue($objRichO);
        $objPHPExcel->getActiveSheet()->getStyle('O'.$u)->getAlignment()->setWrapText(true);


        //echo "MONTH: ".$year. " || VALUE DATA Succes BANK: ".$volume_data_succes_bank."  ||  VALUE DATA Echoue BANK : ".$volume_data_echoue_bank."<br>";
        //echo "MONTH: ".$year. " || VALUE DATA Succes EDP: ".$volume_data_succes_edp."  ||  VALUE DATA Echoue EDP : ".$volume_data_echoue_edp."<br>";
        $u++;
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_value_vulume_enrolement_bank($date_data,$type,$var_condition,$type_bank)
{
    $value_data = "0";
    $connexion=ma_db_connexion();
    $condition = '';
    $date_condition = "AND DATE_FORMAT(`date_enrol` , '".$var_condition."') = '".$date_data."'";
    $group_by ="GROUP BY DATE_FORMAT(`date_enrol` , '".$var_condition."')";
    if ($type === 0)
    {
        $condition = "status='Succès'";
    }
    else if($type === 1){
        $condition = "status='Abandoné'";
    }
    else if($type === 2){
        $condition = "status='echoué'";
    }

    if ($date_data === 'Total')
    {
        $date_condition = ' ';
        $group_by = ' ';
    }
    $SQL = "SELECT SUM(number_enrol) as value_data FROM `enrolement_echoue_abandon`,membre WHERE 
    enrolement_echoue_abandon.bank_code = membre.code_membre and membre.type_membre = '".$type_bank."' AND  ".$condition."  ".$date_condition." ".$group_by." ORDER BY date_enrol ASC";


    //echo $SQL."<br><br><br>";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $value_data=$row["value_data"];
            }

        }
    }
    mysqli_close($connexion);
    return $value_data;
}

function get_enrolement_mensuel($date_data,$type,$var_condition,$type_bank)
{
    $value_data = "0";
    $connexion=ma_db_connexion();
    $condition = '';
    $date_condition = "AND DATE_FORMAT(`date_enrol` , '".$var_condition."') = '".$date_data."'";
    $group_by ="GROUP BY DATE_FORMAT(`date_enrol` , '".$var_condition."')";
    if ($type === 0)
    {
        $condition = "status='Succès'";
    }
    else if($type === 1){
        $condition = "status='Abandoné'";
    }
    else if($type === 2){
        $condition = "status='echoué'";
    }

    if ($date_data === 'Total')
    {
        $date_condition = ' ';
        $group_by = ' ';
    }
    $SQL = "SELECT SUM(number_enrol) as value_data FROM `enrolement_echoue_abandon`,membre WHERE 
    enrolement_echoue_abandon.bank_code = membre.code_membre and membre.type_membre = '".$type_bank."' AND  ".$condition."  ".$date_condition." ".$group_by." ORDER BY date_enrol ASC";


    //echo $SQL."<br><br><br>";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $value_data=$row["value_data"];
            }

        }
    }
    mysqli_close($connexion);
    return $value_data;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_indicateurs_mensuels_vol_mont($objPHPExcel,$u,$styleService_Det,$styleService_Detail,$styleService_gris_clair)
{
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    /*$objPHPExcel->getActiveSheet()->setSharedStyle($styleService_Det, 'A'.$u.':B'.$u);
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Indicateurs Mensuels";
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($NomTitre_2);
    $objPHPExcel->getActiveSheet()->mergeCells('A'.$u.':B'.$u);*/


    $u = $u+3;
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Volume (Trx)');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':D'.$u);


    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue('Montant (Mad)');
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('E'.$u.':G'.$u);

    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->applyFromArray($styleService_gris_clair);


    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue('Abandoné');
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('F'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('F'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('G'.$u)->setValue('Abandoné');
    $objPHPExcel->getActiveSheet()->getStyle('G'.$u)->applyFromArray($styleService_gris_clair);

    $all_month = get_all_month_enrolement();


    $u++;

    foreach($all_month as  $month)
    {
        $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);


        $objRichA = new PHPExcel_RichText();
        $A=convert_month_to_french_excel($month[1]);
        $objA = $objRichA->createTextRun($A);
        $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_gris_clair);

        $volume_data_succes = get_enrolement_annuel($month[0],0,'%Y-%m');
        $volume_data_echoue = get_enrolement_annuel($month[0],2,'%Y-%m');
        $volume_data_aband = get_enrolement_annuel($month[0],1,'%Y-%m');


        $montant_data_succes = get_value_montant_enrolement($month[0],0);
        $montant_data_echoue = get_value_montant_enrolement($month[0],1);
        $montant_data_aband = get_value_montant_enrolement($month[0],2);


        $objRichB = new PHPExcel_RichText();
        $B=$volume_data_succes;
        $objB = $objRichB->createTextRun($B);
        $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($objRichB);
        $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

        $objRichC = new PHPExcel_RichText();
        $C=$volume_data_echoue;
        $objC = $objRichC->createTextRun($C);
        $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($objRichC);
        $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

        $objRichD = new PHPExcel_RichText();
        $D=$volume_data_aband;
        $objD = $objRichD->createTextRun($D);
        $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($objRichD);
        $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

        $objRichE = new PHPExcel_RichText();
        $E=$montant_data_succes;
        $objE = $objRichE->createTextRun($E);
        $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($objRichE);
        $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

        $objRichF = new PHPExcel_RichText();
        $F=$montant_data_echoue;
        $objF = $objRichF->createTextRun($F);
        $objPHPExcel->getActiveSheet()->getCell('F'.$u)->setValue($objRichF);
        $objPHPExcel->getActiveSheet()->getStyle('F'.$u)->getAlignment()->setWrapText(true);
        //echo "MONTH: ".$month[0]. " || VALUE DATA Succes: ".$volume_data_succes."  ||  VALUE DATA Echoue: ".$volume_data_echoue."<br>";

        $objRichG = new PHPExcel_RichText();
        $G=$montant_data_aband;
        $objG = $objRichG->createTextRun($G);
        $objPHPExcel->getActiveSheet()->getCell('G'.$u)->setValue($objRichG);
        $objPHPExcel->getActiveSheet()->getStyle('G'.$u)->getAlignment()->setWrapText(true);

        $u++;
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_month_enrolement()
{
    $first_mois = date('Y-m-01', strtotime(' - 15 months'));

    $last_mois = date('Y-m-01', strtotime(' - 3 months'));


    $month_data = array();
    $connexion=ma_db_connexion();
    $SQL = "SELECT DATE_FORMAT(`request_date` , '%Y-%m') AS `month_data` ,DATE_FORMAT(`request_date` , '%M-%y') AS `month_data_alfa`  FROM `evolution_cpt_interoperable` WHERE `request_date` BETWEEN '".$first_mois."' AND '".$last_mois."'
    GROUP BY DATE_FORMAT(`request_date` , '%Y-%m') ORDER BY `month_data` ASC ";
    //echo $SQL."<br>";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $month_data[]=[$row["month_data"],$row["month_data_alfa"]];
            }
        }
    }
    mysqli_close($connexion);
    return $month_data;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_indicateurs_annuels_vol_mont($objPHPExcel,$u,$styleService_Det,$styleService_Detail,$styleService_gris_clair)
{
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    /*$objPHPExcel->getActiveSheet()->setSharedStyle($styleService_Det, 'A'.$u.':B'.$u);
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Statut annuel en nombre (Trx) et en montant (Mad)";
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($NomTitre_2);
    $objPHPExcel->getActiveSheet()->mergeCells('A'.$u.':B'.$u);*/


    $u = $u+1;
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Volume (Trx)');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':D'.$u);


    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue('Montant (Mad)');
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('E'.$u.':G'.$u);

    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue('Abandoné');
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('F'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('F'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('G'.$u)->setValue('Abandoné');
    $objPHPExcel->getActiveSheet()->getStyle('G'.$u)->applyFromArray($styleService_gris_clair);

    $all_year = get_all_year_enrolement();
    $u++;

    foreach($all_year as  $year)
    {
        $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

        $objRichA = new PHPExcel_RichText();
        $A=$year;
        $objA = $objRichA->createTextRun($A);
        $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_gris_clair);

        $volume_data_succes = get_enrolement_annuel($year,0,'%Y');
        $volume_data_echoue = get_enrolement_annuel($year,2,'%Y');
        $volume_data_aband = get_enrolement_annuel($year,1,'%Y');



        $montant_data_succes = get_value_montant_enrolement($year,0);
        $montant_data_echoue = get_value_montant_enrolement($year,1);
        $montant_data_aband = get_value_montant_enrolement($year,2);




        $objRichB = new PHPExcel_RichText();
        $B=$volume_data_succes;
        $objB = $objRichB->createTextRun($B);
        $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($objRichB);
        $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

        $objRichC = new PHPExcel_RichText();
        $C=$volume_data_echoue;
        $objC = $objRichC->createTextRun($C);
        $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($objRichC);
        $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

        $objRichD = new PHPExcel_RichText();
        $D=$volume_data_aband;
        $objD = $objRichD->createTextRun($D);
        $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($objRichD);
        $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

        $objRichE = new PHPExcel_RichText();
        $E=$montant_data_succes;
        $objD = $objRichE->createTextRun($E);
        $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($objRichE);
        $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

        $objRichF = new PHPExcel_RichText();
        $F=$montant_data_echoue;
        $objF = $objRichF->createTextRun($F);
        $objPHPExcel->getActiveSheet()->getCell('F'.$u)->setValue($objRichF);
        $objPHPExcel->getActiveSheet()->getStyle('F'.$u)->getAlignment()->setWrapText(true);

        $objRichG = new PHPExcel_RichText();
        $G=$montant_data_aband;
        $objF = $objRichG->createTextRun($G);
        $objPHPExcel->getActiveSheet()->getCell('G'.$u)->setValue($objRichG);
        $objPHPExcel->getActiveSheet()->getStyle('G'.$u)->getAlignment()->setWrapText(true);

        //echo "YEAR : ".$year. " || VALUE DATA Succes: ".$volume_data_succes."  ||  VALUE DATA Echoue: ".$volume_data_echoue."<br>";
        $u++;
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_year_enrolement()
{
    $year_data = array();
    $connexion=ma_db_connexion();
    $SQL = "SELECT DATE_FORMAT(`request_date` , '%Y') AS `year_data` FROM `evolution_cpt_interoperable` 
    GROUP BY DATE_FORMAT(`request_date` , '%Y') ORDER BY `year_data` ASC ";
    //echo $SQL."<br>";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $year_data[]=$row["year_data"];
            }
            $year_data[] = 'Total';
        }
    }
    mysqli_close($connexion);
    return $year_data;
}

////////////////////////////////// ENROLEMENTS ////////////////////////////////////////////////////

function get_enrolement_annuel($date_data,$type,$var_condition)
{
    $value_data = "0";
    $connexion=ma_db_connexion();
    $condition = '';
    $date_condition = "DATE_FORMAT(`date_enrol` , '".$var_condition."') = '".$date_data."' AND";
    $group_by ="GROUP BY DATE_FORMAT(`date_enrol` , '".$var_condition."')";
    if ($type === 0)
    {
        $condition = "status='Succès'";
    }
    else if($type === 1){
        $condition = "status='Abandoné'";
    }
    else if($type === 2){
        $condition = "status='echoué'";
    }

    if ($date_data === 'Total')
    {
        $date_condition = ' ';
        $group_by = ' ';
    }
    $SQL = "SELECT SUM(number_enrol) as value_data FROM `enrolement_echoue_abandon` WHERE ".$date_condition."  ".$condition." ".$group_by." ORDER BY date_enrol ASC ";


    //echo $SQL."<br>";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $value_data=$row["value_data"];
            }

        }
    }
    mysqli_close($connexion);
    return $value_data;
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_value_vulume_enrolement($date_data,$type,$var_condition)
{
    $value_data = "0";
    $connexion=ma_db_connexion();
    $condition = 'AND returned_error_code=00000 ';
    $date_condition = "DATE_FORMAT(`request_date` , '".$var_condition."') = '".$date_data."' AND";
    $group_by ="GROUP BY DATE_FORMAT(`request_date` , '".$var_condition."')";
    if ($type === 1)
    {
        $condition = 'AND returned_error_code<>00000';
    }

    if ($date_data === 'Total')
    {
        $date_condition = ' ';
        $group_by = ' ';
    }
    $SQL = "SELECT SUM(nb_services) as value_data FROM `evolution_cpt_interoperable`
    WHERE ".$date_condition." service_name = 'Enrôlement Client' ".$condition."
    ".$group_by." ORDER BY request_date ASC ";


    //echo $SQL."<br>";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    else
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $value_data=$row["value_data"];
            }

        }
    }
    mysqli_close($connexion);
    return $value_data;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_value_montant_enrolement($date_data,$type)
{
    return '0';
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////// STATUT DES TRANSACTIONS /////////////////////////////////////////////////////////////////


function get_performance_vol_abouti($service,$type_bank,$month){
    

    $value_data = "0";
	$link = ma_db_connexion();
	$sql = "SELECT SUM(nbr) AS value_data FROM `member_autorisation_tablele` JOIN operations ON member_autorisation_tablele.processing_code=operations.processing_code JOIN membre ON member_autorisation_tablele.payeur=membre.code_membre WHERE DATE_FORMAT(`date_author` , '%Y-%m')='".$month."' AND ( action_code=000 OR (action_code=911 AND (member_autorisation_tablele.processing_code=23 or member_autorisation_tablele.processing_code=24 or member_autorisation_tablele.processing_code=01))) AND categorie='".$service."' AND type_membre='".$type_bank."' GROUP BY DATE_FORMAT(`date_author` , '%Y-%m'),type_membre ORDER BY date_author ASC";
	mysqli_query($link,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($link,$sql);
	 if (!$result)
		{
						error_log("Erreur sql service mensuel abouti : ".mysqli_error($link));
						die('ERREUR QUERY service mensuel abouti !');
		}
    if(mysqli_num_rows($result)>0)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            $value_data=$row["value_data"];
        }
    }
    mysqli_close($link);
    return $value_data;


}

function get_performance_mnt_abouti($service,$type_bank,$month){
    

    $value_data = "0";
	$link = ma_db_connexion();
	$sql = "SELECT SUM(montant) AS value_data FROM `member_autorisation_tablele` JOIN operations ON member_autorisation_tablele.processing_code=operations.processing_code JOIN membre ON member_autorisation_tablele.payeur=membre.code_membre WHERE DATE_FORMAT(`date_author` , '%Y-%m')='".$month."' AND ( action_code=000 OR (action_code=911 AND (member_autorisation_tablele.processing_code=23 or member_autorisation_tablele.processing_code=24 or member_autorisation_tablele.processing_code=01))) AND categorie='".$service."' AND type_membre='".$type_bank."' GROUP BY DATE_FORMAT(`date_author` , '%Y-%m'),type_membre ORDER BY date_author ASC";
	mysqli_query($link,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($link,$sql);
	 if (!$result)
		{
						error_log("Erreur sql service mensuel abouti : ".mysqli_error($link));
						die('ERREUR QUERY service mensuel abouti !');
		}
    if(mysqli_num_rows($result)>0)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            $value_data=$row["value_data"];
        }
    }
    mysqli_close($link);
    return $value_data;


}

function get_performance_vol_non_abouti($service,$type_bank,$month){
    

    $value_data = "0";
	$link = ma_db_connexion();
	$sql = "SELECT SUM(nbr) AS value_data FROM `member_autorisation_tablele` JOIN operations ON member_autorisation_tablele.processing_code=operations.processing_code JOIN membre ON member_autorisation_tablele.payeur=membre.code_membre WHERE DATE_FORMAT(`date_author` , '%Y-%m')='".$month."' AND ( action_code<>000 AND (action_code<>911 AND (member_autorisation_tablele.processing_code=23 or member_autorisation_tablele.processing_code=24 or member_autorisation_tablele.processing_code=01))) AND categorie='".$service."' AND type_membre='".$type_bank."' GROUP BY DATE_FORMAT(`date_author` , '%Y-%m'),type_membre ORDER BY date_author ASC";
	mysqli_query($link,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($link,$sql);
	 if (!$result)
		{
						error_log("Erreur sql service mensuel abouti : ".mysqli_error($link));
						die('ERREUR QUERY service mensuel abouti !');
		}
    if(mysqli_num_rows($result)>0)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            $value_data=$row["value_data"];
        }
    }
    mysqli_close($link);
    return $value_data;


}

function get_performance_mnt_non_abouti($service,$type_bank,$month){
    

    $value_data = "0";
	$link = ma_db_connexion();
	$sql = "SELECT SUM(montant) AS value_data FROM `member_autorisation_tablele` JOIN operations ON member_autorisation_tablele.processing_code=operations.processing_code JOIN membre ON member_autorisation_tablele.payeur=membre.code_membre WHERE DATE_FORMAT(`date_author` , '%Y-%m')='".$month."' AND ( action_code<>000 AND (action_code<>911 AND (member_autorisation_tablele.processing_code=23 or member_autorisation_tablele.processing_code=24 or member_autorisation_tablele.processing_code=01))) AND categorie='".$service."' AND type_membre='".$type_bank."' GROUP BY DATE_FORMAT(`date_author` , '%Y-%m'),type_membre ORDER BY date_author ASC";
	mysqli_query($link,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($link,$sql);
	 if (!$result)
		{
						error_log("Erreur sql service mensuel abouti : ".mysqli_error($link));
						die('ERREUR QUERY service mensuel abouti !');
		}
    if(mysqli_num_rows($result)>0)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            $value_data=$row["value_data"];
        }
    }
    mysqli_close($link);
    return $value_data;


}

//if different 1op edp + 1op bank


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function classeur_Fichier_Statut_Transactions($date_data,$objPHPExcel)
{

    $date_last_mois = date('Y-m-d', strtotime(' - 1 months'));

    $objDrawing = new PHPExcel_Worksheet_Drawing();
    $objDrawing->setName('Logo');
    $objDrawing->setDescription('Logo');
    $objDrawing->setPath('img/logo_iprc2.png');
    $objDrawing->setCoordinates('M1');
    $objDrawing->setOffsetX(100);
    $objDrawing->setRotation(0);
    $objDrawing->getShadow()->setVisible(true);
    $objDrawing->getShadow()->setDirection(45);
    $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());


    // Set document properties

    $objPHPExcel->getProperties()->setCreator("HPS");
    ////////////////////////////Style////////////////////////////////////////////////////////////
    $sharedStyle = new PHPExcel_Style();
    $sharedStyle->applyFromArray(
        array('fill' 	=> array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => '002060'),
        )

        ));
    $styleService_Detail = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 9,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'd9d9d9'),
        )
    );
    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );
    $styleService_gris_clair = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 9,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'e8e8e8'),
        )
    );
    $styleService_Det = new PHPExcel_Style();

    $styleService_Det->applyFromArray(array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'      => PHPExcel_Style_Fill::FILL_SOLID,
            'color'     => array('argb' => 'D0EBF6'),
        )
    ));
    ////////////////////////////Title 1////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A6:E6");
    $objRichTitre = new PHPExcel_RichText();
    $NomTitre="Statut mensuel en nombre (Trx) et en montant (Mad) - Service Transfert";

    $objTitre = $objRichTitre->createTextRun($NomTitre);
    $objTitre->getFont()->setBold(true);
    $objTitre->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A6')->setValue($objRichTitre);
    $objPHPExcel->getActiveSheet()->getStyle('A6')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A6:E6');
    $objPHPExcel->getActiveSheet()->getRowDimension('6')->setRowHeight(23);
    ////////////////////////////Title 2////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A28:E28");
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Statut mensuel en nombre (Trx) et en montant (Mad) - Service Paiement";

    $objTitre_2 = $objRichTitre_2->createTextRun($NomTitre_2);
    $objTitre_2->getFont()->setBold(true);
    $objTitre_2->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_2->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A28')->setValue($objRichTitre_2);
    $objPHPExcel->getActiveSheet()->getStyle('A28')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A28:E28');
    $objPHPExcel->getActiveSheet()->getRowDimension('28')->setRowHeight(23);
    ////////////////////////////Title 3////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A50:E50");
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Statut mensuel en nombre (Trx) et en montant (Mad) - Service Cash out";

    $objTitre_2 = $objRichTitre_2->createTextRun($NomTitre_2);
    $objTitre_2->getFont()->setBold(true);
    $objTitre_2->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_2->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A50')->setValue($objRichTitre_2);
    $objPHPExcel->getActiveSheet()->getStyle('A50')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A50:E50');
    $objPHPExcel->getActiveSheet()->getRowDimension('50')->setRowHeight(23);
    ////////////////////////////fin title////////////////////////////////////////////////////////////

    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(14);
    $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(21);

    //************ */

    $u = 8;
    get_indicateurs_mensuel_transfert_vol_mont($objPHPExcel,$u,$styleService_Det,$styleService_Detail,'TRANSFERT',$styleService_gris_clair);

    $u = 30;
    get_indicateurs_mensuel_transfert_vol_mont($objPHPExcel,$u,$styleService_Det,$styleService_Detail,'PAIEMENT',$styleService_gris_clair);

    $u=52;
    get_indicateurs_mensuel_transfert_vol_mont($objPHPExcel,$u,$styleService_Det,$styleService_Detail,'CASH OUT',$styleService_gris_clair);






    /*******************************Fin Rendre function *********************************/
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_indicateurs_mensuel_transfert_vol_mont($objPHPExcel,$u,$styleService_Det,$styleService_Detail,$service,$styleService_gris_clair)
{
    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    /*$objPHPExcel->getActiveSheet()->setSharedStyle($styleService_Det, 'A'.$u.':B'.$u);
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Indicateurs Mensuels";
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($NomTitre_2);
    $objPHPExcel->getActiveSheet()->mergeCells('A'.$u.':B'.$u);*/



    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    $u = $u+1;

    
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':E'.$u);


    $objPHPExcel->getActiveSheet()->getCell('H'.$u)->setValue('BANQUE');
    $objPHPExcel->getActiveSheet()->getStyle('H'.$u)->applyFromArray($styleService);
    $objPHPExcel->getActiveSheet()->mergeCells('H'.$u.':K'.$u);

    $u++;
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Volume (Trx)');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue('Montant (Mad)');
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('D'.$u.':E'.$u);


    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('H'.$u)->setValue('Volume (Trx)');
    $objPHPExcel->getActiveSheet()->getStyle('H'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('H'.$u.':I'.$u);

    $objPHPExcel->getActiveSheet()->getCell('J'.$u)->setValue('Montant (Mad)');
    $objPHPExcel->getActiveSheet()->getStyle('J'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('J'.$u.':K'.$u);

    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('H'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('H'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('I'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('I'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('J'.$u)->setValue('Succès');
    $objPHPExcel->getActiveSheet()->getStyle('J'.$u)->applyFromArray($styleService_gris_clair);

    $objPHPExcel->getActiveSheet()->getCell('K'.$u)->setValue('échoué');
    $objPHPExcel->getActiveSheet()->getStyle('K'.$u)->applyFromArray($styleService_gris_clair);




    $all_month = get_all_month_enrolement();

    //var_dump($all_month);


    $u++;

    foreach($all_month as  $month)
    {

        //var_dump($month);
        $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);


        $objRichA = new PHPExcel_RichText();
        $A=convert_month_to_french_excel($month[1]);
        $objA = $objRichA->createTextRun($A);
        $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_gris_clair);

        $objPHPExcel->getActiveSheet()->getCell('G'.$u)->setValue($objRichA);
        $objPHPExcel->getActiveSheet()->getStyle('G'.$u)->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('G'.$u)->applyFromArray($styleService_gris_clair);


        //$service,$type_bank,$month
        //abouti
        $volume_abouti_banque = get_performance_vol_abouti($service,'BANQUE',$month[0]);
        $volume_abouti_edp = get_performance_vol_abouti($service,'EDP',$month[0]);
        $mnt_abouti_banque = get_performance_mnt_abouti($service,'BANQUE',$month[0]);
        $mnt_abouti_edp = get_performance_mnt_abouti($service,'EDP',$month[0]);

        //non abouti
        $volume_non_abouti_banque = get_performance_vol_non_abouti($service,'BANQUE',$month[0]);
        $volume_non_abouti_edp = get_performance_vol_non_abouti($service,'EDP',$month[0]);
        $mnt_non_abouti_banque = get_performance_mnt_non_abouti($service,'BANQUE',$month[0]);
        $mnt_non_abouti_edp = get_performance_mnt_non_abouti($service,'EDP',$month[0]);



        //EDP
        $objRichB = new PHPExcel_RichText();
        $B=$volume_abouti_edp;
        $objB = $objRichB->createTextRun($B);
        $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($objRichB);
        $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

        $objRichC = new PHPExcel_RichText();
        $C=$volume_non_abouti_edp;
        $objC = $objRichC->createTextRun($C);
        $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($objRichC);
        $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

        $objRichD = new PHPExcel_RichText();
        $D=$mnt_abouti_edp;
        $objD = $objRichD->createTextRun($D);
        $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($objRichD);
        $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

        $objRichE = new PHPExcel_RichText();
        $E=$mnt_non_abouti_edp;
        $objE = $objRichE->createTextRun($E);
        $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($objRichE);
        $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

        //BANK
        $objRichH = new PHPExcel_RichText();
        $H=$volume_abouti_banque;
        $objH = $objRichH->createTextRun($H);
        $objPHPExcel->getActiveSheet()->getCell('H'.$u)->setValue($objRichH);
        $objPHPExcel->getActiveSheet()->getStyle('H'.$u)->getAlignment()->setWrapText(true);

        $objRichI = new PHPExcel_RichText();
        $I=$volume_non_abouti_banque;
        $objI = $objRichI->createTextRun($I);
        $objPHPExcel->getActiveSheet()->getCell('I'.$u)->setValue($objRichI);
        $objPHPExcel->getActiveSheet()->getStyle('I'.$u)->getAlignment()->setWrapText(true);

        $objRichJ = new PHPExcel_RichText();
        $J=$mnt_abouti_banque;
        $objH = $objRichJ->createTextRun($J);
        $objPHPExcel->getActiveSheet()->getCell('J'.$u)->setValue($objRichJ);
        $objPHPExcel->getActiveSheet()->getStyle('J'.$u)->getAlignment()->setWrapText(true);

        $objRichK = new PHPExcel_RichText();
        $K=$mnt_non_abouti_banque;
        $objI = $objRichK->createTextRun($K);
        $objPHPExcel->getActiveSheet()->getCell('K'.$u)->setValue($objRichK);
        $objPHPExcel->getActiveSheet()->getStyle('K'.$u)->getAlignment()->setWrapText(true);


        $u++;
    }
}


function classeur_Fichier_Statut_Rejets($date_data,$objPHPExcel)
{

    $date_last_mois = date('Y-m-d', strtotime(' - 1 months'));

    $objDrawing = new PHPExcel_Worksheet_Drawing();
    $objDrawing->setName('Logo');
    $objDrawing->setDescription('Logo');
    $objDrawing->setPath('img/logo_iprc2.png');
    $objDrawing->setCoordinates('M1');
    $objDrawing->setOffsetX(100);
    $objDrawing->setRotation(0);
    $objDrawing->getShadow()->setVisible(true);
    $objDrawing->getShadow()->setDirection(45);
    $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());


    // Set document properties

    $objPHPExcel->getProperties()->setCreator("HPS");
    ////////////////////////////Style////////////////////////////////////////////////////////////
    $sharedStyle = new PHPExcel_Style();
    $sharedStyle->applyFromArray(
        array('fill' 	=> array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => '002060'),
        )

        ));
    $styleService_Detail = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 9,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'd9d9d9'),
        )
    );
    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );
    $styleService_Det = new PHPExcel_Style();

    $styleService_Det->applyFromArray(array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'      => PHPExcel_Style_Fill::FILL_SOLID,
            'color'     => array('argb' => 'D0EBF6'),
        )
    ));


    $current_year=date("Y");

    $number=date('m', strtotime('-3 MONTH'))-1;
	$mois_abb=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Décembre'];
	$lastMonth=$mois_abb[$number];


    ////////////////////////////Title 1////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A6:E6");
    $objRichTitre = new PHPExcel_RichText();
    $NomTitre="Top des rejets par typologie ".$lastMonth." ".$current_year." - Service Transfert";

    $objTitre = $objRichTitre->createTextRun($NomTitre);
    $objTitre->getFont()->setBold(true);
    $objTitre->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A6')->setValue($objRichTitre);
    $objPHPExcel->getActiveSheet()->getStyle('A6')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A6:E6');
    $objPHPExcel->getActiveSheet()->getRowDimension('6')->setRowHeight(23);
    ////////////////////////////Title 2////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A29:E29");
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Top des rejets par typologie ".$lastMonth." ".$current_year." - Service Paiement";

    $objTitre_2 = $objRichTitre_2->createTextRun($NomTitre_2);
    $objTitre_2->getFont()->setBold(true);
    $objTitre_2->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_2->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A29')->setValue($objRichTitre_2);
    $objPHPExcel->getActiveSheet()->getStyle('A29')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A29:E29');
    $objPHPExcel->getActiveSheet()->getRowDimension('29')->setRowHeight(23);
    ////////////////////////////Title 3////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A50:E50");
    $objRichTitre_2 = new PHPExcel_RichText();
    $NomTitre_2="Top des rejets par typologie ".$lastMonth." ".$current_year." - Service Cash Out";

    $objTitre_2 = $objRichTitre_2->createTextRun($NomTitre_2);
    $objTitre_2->getFont()->setBold(true);
    $objTitre_2->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_2->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A50')->setValue($objRichTitre_2);
    $objPHPExcel->getActiveSheet()->getStyle('A50')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A50:E50');
    $objPHPExcel->getActiveSheet()->getRowDimension('50')->setRowHeight(23);
    ////////////////////////////fin title////////////////////////////////////////////////////////////


    ////////////////////////////Title 4////////////////////////////////////////////////////////////
    $objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle, "A70:E70");
    $objRichTitre_3 = new PHPExcel_RichText();
    $NomTitre_2="Librairie des raisons de rejets";

    $objTitre_2 = $objRichTitre_3->createTextRun($NomTitre_2);
    $objTitre_2->getFont()->setBold(true);
    $objTitre_2->getFont()->setSize(12);
    //$objTitre->getFont()->setItalic(true);
    $objTitre_2->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_WHITE ) );

    $objPHPExcel->getActiveSheet()->getCell('A70')->setValue($objRichTitre_3);
    $objPHPExcel->getActiveSheet()->getStyle('A70')->getAlignment()->setVertical('center');
    $objPHPExcel->getActiveSheet()->mergeCells('A70:E70');
    $objPHPExcel->getActiveSheet()->getRowDimension('70')->setRowHeight(23);
    ////////////////////////////fin title////////////////////////////////////////////////////////////

    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(14);
    $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(21);
    $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(21);

   //$objPHPExcel->getActiveSheet()->mergeCells('A32:A35');
   //$objPHPExcel->getActiveSheet()->mergeCells('A36:A39');
   //$objPHPExcel->getActiveSheet()->mergeCells('A40:A43');
//
   //$objPHPExcel->getActiveSheet()->mergeCells('A54:A57');
   //$objPHPExcel->getActiveSheet()->mergeCells('A58:A61');
   //$objPHPExcel->getActiveSheet()->mergeCells('A62:65');

    //$objPHPExcel->getActiveSheet()->mergeCells('A32:A35');
    //$objPHPExcel->getActiveSheet()->mergeCells('A36:A39');
    //$objPHPExcel->getActiveSheet()->mergeCells('A40:A43');

    //************ */

    $u = 8;
    $date_previous=date('Y-m-d', strtotime(' - 3 months'));
    get_indicateurs_rejets_transfert($objPHPExcel,$u,$styleService_Det,$styleService_Detail,'TRANSFERT',$date_previous);

    $u = 31;
    get_indicateurs_rejets_paiement($objPHPExcel,$u,$styleService_Det,$styleService_Detail,'PAIEMENT',$date_previous);

    $u=53;
    get_indicateurs_rejets_cash($objPHPExcel,$u,$styleService_Det,$styleService_Detail,'CASH OUT',$date_previous);

    $u=74;
    get_indicateurs_annexe_rejets($objPHPExcel,$u,$styleService_Det,$styleService_Detail);






    /*******************************Fin Rendre function *********************************/
}

function get_indicateurs_rejets_transfert($objPHPExcel,$u,$styleService_Det,$styleService_Detail,$service,$date_previous)
{


    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    //$u = $u+3;




    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue('Typologie');
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_Detail);


    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Rejets');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_Detail);
    //$objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('NB transaction');
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->applyFromArray($styleService_Detail);
    //$objPHPExcel->getActiveSheet()->mergeCells('D'.$u.':E'.$u);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue('TRG 1 (%)');
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService_Detail);
    //$objPHPExcel->getActiveSheet()->mergeCells('F'.$u.':G'.$u);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue('TRG 2 (%)');
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_Detail);
    //$objPHPExcel->getActiveSheet()->mergeCells('H'.$u.':I'.$u);

    //table 1 : 

    $objPHPExcel->getActiveSheet()->getCell('A9')->setValue('SWITCH');
    $objPHPExcel->getActiveSheet()->getCell('A14')->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getCell('A20')->setValue('BANQUE');
   

    $objPHPExcel->getActiveSheet()->mergeCells('A9:A13');
    $objPHPExcel->getActiveSheet()->mergeCells('A14:A19');
    $objPHPExcel->getActiveSheet()->mergeCells('A20:A27');






    $u++;

    $rejets=genere_table_top_rejet($service,$date_previous);



    //ligne 1 :

    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[0][0]); 
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[0][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[0][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[0][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[0][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 2 :     $u++;
    $u++;

    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[1][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[1][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[1][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[1][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[1][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 3 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[2][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[2][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[2][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[2][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[2][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 4 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[3][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[3][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[3][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[3][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[3][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 5 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[4][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[4][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[4][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[4][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[4][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    $u++;


    //ligne 6 :
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[5][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[5][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[5][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[5][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[5][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 7 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[6][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[6][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[6][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[6][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[6][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 8 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[7][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[7][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[7][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[7][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[7][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 9 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[8][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[8][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[8][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[8][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[8][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 10 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[9][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[9][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[9][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[9][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[9][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);
    
    //ligne 11 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[10][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[10][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[10][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[10][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[10][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 12 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[11][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[11][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[11][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[11][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[11][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);


    $u++;
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[12][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[12][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[12][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[12][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);


    $u++;
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[13][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[13][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[13][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[13][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);


    $u++;
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[14][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[14][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[14][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[14][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    $u++;
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[15][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[15][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[15][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[15][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    $u++;
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[16][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[16][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[16][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[16][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    $u++;
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[17][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[17][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[17][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[17][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);


    $u++;
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[18][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[18][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[18][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[18][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);
}

function get_indicateurs_rejets_paiement($objPHPExcel,$u,$styleService_Det,$styleService_Detail,$service,$date_previous)
{


    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    //$u = $u+3;




    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue('Typologie');
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_Detail);


    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Rejets');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_Detail);
    //$objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('NB transaction');
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->applyFromArray($styleService_Detail);
    //$objPHPExcel->getActiveSheet()->mergeCells('D'.$u.':E'.$u);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue('TRG 1 (%)');
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService_Detail);
    //$objPHPExcel->getActiveSheet()->mergeCells('F'.$u.':G'.$u);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue('TRG 2 (%)');
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_Detail);
    //$objPHPExcel->getActiveSheet()->mergeCells('H'.$u.':I'.$u);

 

    //table 2 :

    $objPHPExcel->getActiveSheet()->getCell('A32')->setValue('SWITCH');
    $objPHPExcel->getActiveSheet()->getCell('A36')->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getCell('A43')->setValue('BANQUE');
   

    $objPHPExcel->getActiveSheet()->mergeCells('A32:A35');
    $objPHPExcel->getActiveSheet()->mergeCells('A36:A42');
    $objPHPExcel->getActiveSheet()->mergeCells('A43:A46');






    $u++;

    $rejets=genere_table_top_rejet($service,$date_previous);



    //ligne 1 :

    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[0][0]); 
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[0][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[0][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[0][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[0][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 2 :     $u++;
    $u++;

    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[1][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[1][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[1][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[1][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[1][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 3 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[2][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[2][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[2][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[2][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[2][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 4 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[3][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[3][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[3][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[3][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[3][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 5 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[4][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[4][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[4][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[4][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[4][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    $u++;


    //ligne 6 :
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[5][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[5][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[5][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[5][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[5][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 7 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[6][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[6][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[6][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[6][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[6][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 8 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[7][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[7][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[7][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[7][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[7][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 9 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[8][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[8][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[8][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[8][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[8][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 10 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[9][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[9][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[9][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[9][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[9][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);
    
    //ligne 11 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[10][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[10][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[10][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[10][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[10][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 12 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[11][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[11][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[11][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[11][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[11][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);


    $u++;
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[12][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[12][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[12][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[12][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    $u++;
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[13][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[13][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[13][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[13][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    $u++;
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[14][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[14][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[14][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[14][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);


}

function get_indicateurs_rejets_cash($objPHPExcel,$u,$styleService_Det,$styleService_Detail,$service,$date_previous)
{


    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    //$u = $u+3;




    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue('Typologie');
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_Detail);


    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Rejets');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_Detail);
    //$objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue('NB transaction');
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->applyFromArray($styleService_Detail);
    //$objPHPExcel->getActiveSheet()->mergeCells('D'.$u.':E'.$u);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue('TRG 1 (%)');
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->applyFromArray($styleService_Detail);
    //$objPHPExcel->getActiveSheet()->mergeCells('F'.$u.':G'.$u);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue('TRG 2 (%)');
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->applyFromArray($styleService_Detail);
    //$objPHPExcel->getActiveSheet()->mergeCells('H'.$u.':I'.$u);

  

    //table 3 :

    $objPHPExcel->getActiveSheet()->getCell('A54')->setValue('SWITCH');
    $objPHPExcel->getActiveSheet()->getCell('A58')->setValue('EDP');
    $objPHPExcel->getActiveSheet()->getCell('A62')->setValue('BANQUE');
   

    $objPHPExcel->getActiveSheet()->mergeCells('A54:A57');
    $objPHPExcel->getActiveSheet()->mergeCells('A58:A61');
    $objPHPExcel->getActiveSheet()->mergeCells('A62:A65');




    $u++;

    $rejets=genere_table_top_rejet($service,$date_previous);


    //ligne 1 :

    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[0][0]); 
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[0][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[0][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[0][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[0][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 2 :     $u++;
    $u++;

    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[1][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[1][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[1][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[1][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[1][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 3 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[2][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[2][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[2][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[2][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[2][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 4 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[3][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[3][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[3][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[3][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[3][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 5 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[4][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[4][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[4][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[4][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[4][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    $u++;


    //ligne 6 :
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[5][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[5][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[5][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[5][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[5][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 7 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[6][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[6][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[6][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[6][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[6][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 8 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[7][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[7][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[7][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[7][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[7][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 9 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[8][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[8][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[8][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[8][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[8][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 10 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[9][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[9][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[9][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[9][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[9][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);
    
    //ligne 11 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[10][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[10][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[10][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[10][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[10][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);

    //ligne 12 :
    $u++;
    //$objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    //$objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($rejets[11][0]);  //typo
    //$objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($rejets[11][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('C'.$u)->setValue($rejets[11][2]);   //nb
    $objPHPExcel->getActiveSheet()->getStyle('C'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('D'.$u)->setValue($rejets[11][3]);   //trg1
    $objPHPExcel->getActiveSheet()->getStyle('D'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('E'.$u)->setValue($rejets[11][4]);   //trg2
    $objPHPExcel->getActiveSheet()->getStyle('E'.$u)->getAlignment()->setWrapText(true);


    $u++;


}

function get_indicateurs_annexe_rejets($objPHPExcel,$u,$styleService_Det,$styleService_Detail)
{


    $styleService = array(
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Calibri'
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),'fill' => array(
            'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'bfbfbf'),
        )
    );

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    
    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue('Code de rejets');
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->applyFromArray($styleService_Detail);


    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue('Signification');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->applyFromArray($styleService_Detail);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);

 

    $errors=get_errors();

    $u++;

    //ligne 1 :

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][0]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][0]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    //ligne 2 :
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][1]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][1]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);



    //ligne 1 :
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][2]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][2]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);



    //ligne 1 :
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][3]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][3]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);



    //ligne 1 :
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][4]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][4]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    //ligne 1 :
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][5]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][5]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    //ligne 1 :
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][6]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][6]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    //ligne 1 :
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][7]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][7]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    //ligne 1 :
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][8]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][8]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    //ligne 1 :
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][9]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][9]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    //ligne 1 :
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][10]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][10]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    //ligne 1 :
    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][11]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][11]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][12]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][12]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][13]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][13]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][14]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][14]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][15]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][15]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][16]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][16]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][17]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][17]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][18]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][18]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][19]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][19]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][20]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][20]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);

    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][21]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][21]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);

    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][22]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][22]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);


    $u++;

    $objPHPExcel->getActiveSheet()->getRowDimension($u)->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getCell('A'.$u)->setValue($errors[0][23]);  //typo
    $objPHPExcel->getActiveSheet()->getStyle('A'.$u)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getCell('B'.$u)->setValue($errors[1][23]);  //err
    $objPHPExcel->getActiveSheet()->getStyle('B'.$u)->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->mergeCells('B'.$u.':C'.$u);





}




//-------------- function rejets : ----------------------

function genere_table_top_rejet($service,$date_previous){

	$data_switch=top_rejet_switch($service,$date_previous);
	$data_membre=top_rejet_edp_bank($service,$date_previous);
	$data_transactions=nombre_total_transactions($service,$date_previous);


	$nbr_switch=$data_switch[0];
	$desc_switch=$data_switch[1];
	$nbr_membre=$data_membre[0];
	$desc_membre=$data_membre[1];
	$membre=$data_membre[2];

		
	$nbr_edp=array();
	$nbr_bank=array();
	$desc_edp=array();
	$desc_bank=array();

	for($i=0; $i<count($nbr_membre); $i+=1){
		if($membre[$i]=="BANQUE"){
			array_push($nbr_bank, intval($nbr_membre[$i]));
			array_push($desc_bank, $desc_membre[$i]);
		}
		elseif($membre[$i]=="EDP"){
			array_push($nbr_edp, intval($nbr_membre[$i]));
			array_push($desc_edp, $desc_membre[$i]);
		}

	}

	




	$nbr_membre=intvalarray($nbr_membre);
	$nbr_switch=intvalarray($nbr_switch);

	//calcul du TRG%

	$trg_switch=array();
	$trg_edp=array();
	$trg_bank=array();


	$total=intval(array_sum($nbr_membre)+array_sum($nbr_switch));

	/*while (count($nbr_edp)>4) {
		array_pop($nbr_edp);
		array_pop($desc_edp);
	}

	while (count($nbr_bank)>4) {
		array_pop($nbr_bank);
		array_pop($desc_bank);
	}

	while (count($nbr_switch)>4) {
		array_pop($nbr_switch);
		array_pop($desc_switch);
	}*/

	for($i=0; $i<count($nbr_membre); $i+=1){
		if($membre[$i]=="BANQUE"){
			array_push($trg_bank, number_format(($nbr_membre[$i]/$total)*100,2).'%');
		}
		elseif($membre[$i]=="EDP"){
			array_push($trg_edp, number_format(($nbr_membre[$i]/$total)*100,2).'%');
		}

	}

	for($i=0; $i<count($nbr_switch); $i+=1){
		array_push($trg_switch, number_format(($nbr_switch[$i]/$total)*100,2).'%');
	}




	//calcul du P%

	$p_switch=array();
	$p_edp=array();
	$p_bank=array();
	$libelle=array();

	for($i=0; $i<count($nbr_membre); $i+=1){

		if($membre[$i]=="BANQUE"){
			
			array_push($p_bank, number_format(($nbr_membre[$i]/intval($data_transactions[0][0]))*100,2).'%');
			array_push($libelle, 'BANQUE');
		}
		elseif($membre[$i]=="EDP"){
			array_push($p_edp, number_format(($nbr_membre[$i]/intval($data_transactions[0][0]))*100,2).'%');
			array_push($libelle, 'EDP');
		}
		

	}

	for($i=0; $i<count($nbr_switch); $i+=1){
		array_push($p_switch, number_format(($nbr_switch[$i]/intval($data_transactions[0][0]))*100,2).'%');
	}



	if (count($nbr_switch)<4){
		
		$diff=4-count($nbr_switch);
		for($i=0; $i<$diff; $i+=1){
			array_push($nbr_switch,0);
			array_push($trg_switch,0);
			array_push($p_switch,0);
			array_push($desc_switch,"___________");

		}
	}
	if (count($nbr_edp)<4){
		
		$diff=4-count($nbr_edp);
		for($i=0; $i<$diff; $i+=1){
			array_push($nbr_edp,0);
			array_push($trg_edp,0);
			array_push($p_edp,0);
			array_push($desc_edp,"___________");

		}
	}

	if (count($nbr_bank)<4){
		
		$diff=4-count($nbr_bank);
		for($i=0; $i<$diff; $i+=1){
			array_push($nbr_bank,0);
			array_push($trg_bank,0);
			array_push($p_bank,0);
			array_push($desc_bank,"___________");

		}
	}


	//chaque ligne contient :
	$rejets=array();  //libelle,rejet,nbr,p,TRG
	$values=array();

	for($i=0; $i<count($nbr_switch); $i+=1){

		    
			array_push($values,'Switch');
			array_push($values, $desc_switch[$i]);
			array_push($values, $nbr_switch[$i]);
			array_push($values, $p_switch[$i]);
			array_push($values, $trg_switch[$i]);
			array_push($rejets, $values);
			$values=array();

	}

	for($i=0; $i<count($nbr_edp); $i+=1){

		    
		array_push($values,'EDP');
		array_push($values, $desc_edp[$i]);
		array_push($values, $nbr_edp[$i]);
		array_push($values, $p_edp[$i]);
		array_push($values, $trg_edp[$i]);
		array_push($rejets, $values);
		$values=array();
	}

	for($i=0; $i<count($nbr_bank); $i+=1){

		    
		array_push($values,'Banque');
		array_push($values, $desc_bank[$i]);
		array_push($values, $nbr_bank[$i]);
		array_push($values, $p_bank[$i]);
		array_push($values, $trg_bank[$i]);
		array_push($rejets, $values);
		$values=array();
	}

	return $rejets;
}